package main

import (
	"context"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
)

func TestSessionIndexArithmeticRejectsOverflow(t *testing.T) {
	highest := sessionIntMaxValue()
	for _, tc := range []struct {
		a, b int
		ok   bool
	}{
		{0, 0, true},
		{highest - 1, 1, true},
		{highest, 1, false},
		{highest, 0, true},
		{-1, 1, false},
		{1, -1, false},
	} {
		got, ok := addSessionInt(tc.a, tc.b)
		if ok != tc.ok {
			t.Fatalf("addSessionInt(%d, %d): got %d, ok=%v; want ok=%v", tc.a, tc.b, got, ok, tc.ok)
		}
		if ok && got != tc.a+tc.b {
			t.Fatalf("addSessionInt(%d, %d) = %d", tc.a, tc.b, got)
		}
	}
}

func TestLongRunningSessionKeepsResidentContextBounded(t *testing.T) {
	path := filepath.Join(t.TempDir(), "long-run.json")
	s := newSession()
	t.Cleanup(s.close)
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}

	const rounds = 240
	const payloadSize = 1024
	payload := strings.Repeat("x", payloadSize)
	for i := 0; i < rounds; i++ {
		s.Transcript = append(s.Transcript,
			Message{Role: "user", Content: "request " + payload},
			Message{Role: "assistant", Content: "result " + payload},
		)
		if err := checkpointSession(path, s); err != nil {
			t.Fatalf("checkpoint at round %d: %v", i, err)
		}
		if i%4 == 3 {
			beforeCompact := s.contextBytes()
			summary := "Task: complete all 240 rounds. Completed through round " + strconv.Itoa(i+1) + ". Next: continue."
			result := s.editMemory(summary, 0)
			if strings.HasPrefix(result, "Error") {
				t.Fatalf("memory edit at round %d: %s", i, result)
			}
			if len(s.Transcript) != 1 {
				t.Fatalf("compaction retained removed transcript messages at round %d: %d messages", i, len(s.Transcript))
			}
			if afterCompact := s.contextBytes(); afterCompact >= beforeCompact {
				t.Fatalf("compaction did not shrink the current prompt at round %d: before=%d after=%d", i, beforeCompact, afterCompact)
			}

		}

	}

	if s.owner == nil || s.owner.file == nil {
		t.Fatal("continuous checkpoint has no owned file handle")
	}
	state, err := readSessionLog(s.owner.file, nil)
	if err != nil {
		t.Fatalf("read long-running archive through its owner: %v", err)
	}
	wantCount := 1 + rounds*2
	if state.Count != wantCount || state.Cursor != wantCount {
		t.Fatalf("wrong long-running indices: got count=%d cursor=%d; want %d", state.Count, state.Cursor, wantCount)
	}

	// The old messages remain available through explicit history reads but are
	// not put back into the resident transcript or the next model prompt.
	history, err := s.readHistory(context.Background(), 1, 3)
	if err != nil {
		t.Fatal(err)
	}
	if len(history.Messages) != 2 || !strings.Contains(history.Messages[0].Message.Content.(string), "request") ||
		!strings.Contains(history.Messages[1].Message.Content.(string), "result") {
		t.Fatalf("archived history is not readable: %+v", history)
	}
	if len(s.Transcript) != 1 || len(s.contextMessages()) != 2 {
		t.Fatalf("history read rehydrated old history into model context: transcript=%d context=%d", len(s.Transcript), len(s.contextMessages()))
	}
}

func TestLargeSummaryRoundTripsWithoutFixedLimit(t *testing.T) {
	s := newSession()
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "keep this task"})
	summary := strings.Repeat("verified fact; ", 4096)
	if result := s.editMemory(summary, 0); strings.HasPrefix(result, "Error") {
		t.Fatalf("large summary was rejected: %s", result)
	}
	if s.Memory != summary || s.Cursor != s.messageCount() || len(s.Transcript) != 1 {
		t.Fatal("large summary was not applied atomically")
	}

	path := filepath.Join(t.TempDir(), "large-summary.json")
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	s.close()
	loaded, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(loaded.close)
	if loaded.Memory != summary || len(loaded.Transcript) != 1 {
		t.Fatal("large summary changed across persistence")
	}
}

func TestSessionAppendRejectsAbsoluteIndexOverflow(t *testing.T) {
	s := newSession()
	t.Cleanup(s.close)
	s.archived = sessionIntMaxValue() - 1
	before := append([]Message(nil), s.Transcript...)
	if count, err := s.messageCountChecked(); err != nil || count != sessionIntMaxValue() {
		t.Fatalf("boundary fixture is invalid: count=%d err=%v", count, err)
	}
	if err := ensureSessionAppendFits(s, 1); err == nil {
		t.Fatal("append beyond the absolute-index range was accepted")
	}
	if err := appendSessionMessages(s, Message{Role: "user", Content: "must not append"}); err == nil {
		t.Fatal("overflowed append was accepted")
	}
	if len(s.Transcript) != len(before) || s.Transcript[0].Content != before[0].Content {
		t.Fatal("rejected append changed the transcript")
	}
}
