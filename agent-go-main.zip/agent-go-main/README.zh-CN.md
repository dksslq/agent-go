# agent-go

[English](README.md) · **简体中文**

## 把真实的系统操作能力交给 AI

agent-go 是一个面向自主化 AI 生产的轻量、有状态执行环境。它将兼容 OpenAI 的流式 Chat Completions 模型连接到本地系统工具，使 Agent 能够规划任务、运行程序、观察结果、调整下一步行动，并跨会话继续工作。

它的目标不是再做一个聊天界面，而是在 AI Agent 与真实操作系统之间提供一个精简的执行循环。

[![CI](https://github.com/dksslq/agent-go/actions/workflows/ci.yml/badge.svg)](https://github.com/dksslq/agent-go/actions/workflows/ci.yml) · [发布版本](https://github.com/dksslq/agent-go/releases) · [MIT 许可证](LICENSE)

- **行动：** 运行本地程序，检查标准输出、标准错误和退出码。
- **观察：** 接收工具执行结果，并据此决定下一步行动。
- **记忆：** 维护语义记忆、压缩已完成的历史，并读取归档消息。
- **续行：** 显式保存会话，之后继续多阶段调查或任务。
- **易部署：** 各平台单个 Go 二进制，无第三方 Go 依赖，无 cgo。

支持 Linux、macOS、Windows 的 amd64 和 arm64。构建需要 Go 1.21+。会话文件使用全新的无版本标志 JSON 数组格式；旧会话格式不做迁移。

发布二进制与 Debian 包统一使用 `CGO_ENABLED=0` 和 `-ldflags "-s -w -buildid=" -trimpath`。

## 快速开始

通过 Go 安装：

~~~bash
go install github.com/dksslq/agent-go@main
~~~

配置一个兼容 OpenAI 的接口。对于不需要认证的本地服务，可以不设置 API Key。

~~~bash
export AGENT_API_BASE="http://localhost:8080/v1"
export AGENT_MODEL="your-model"
export AGENT_API_KEY="your-key" # 服务需要时才设置

agent-go
~~~

默认 API 地址是 http://localhost:8080/v1。服务必须支持流式 Chat Completions 和工具调用。图片分析还要求模型和接口支持视觉输入。

执行一项自主任务后退出：

~~~bash
agent-go -once -prompt "检查当前仓库，运行 go test ./...，用证据解释失败原因，不要修改文件。"
~~~

通过 stdin 输入数据。输入内容会与提示词合并，-pipe 会隐含单次执行模式：

~~~bash
cat build.log | agent-go -pipe -prompt "分析构建日志，按根因归类失败，引用证据并建议下一步检查。" > build-report.md
~~~

输出保持真正的流式行为：模型文本到达后立即写出，不会为了重试而缓存或撤回已输出内容。如果流在输出部分正文后失败，agent-go 会在继续重试前写入明确的标记：`[agent-go: response interrupted; preceding output may be incomplete]`。后续重试即使成功，进程也可能以状态码 0 退出，因此下游程序除了检查退出码，还应检查 stdout 中是否包含此标记。若输出目标已损坏、阻塞或运行正在取消，标记可能无法写出。

Windows PowerShell 中可以通过 $env:AGENT_API_BASE、$env:AGENT_MODEL 以及（服务需要时）$env:AGENT_API_KEY 设置环境变量；可执行文件名为 agent-go.exe。发布后的预编译二进制会附在 [Releases](https://github.com/dksslq/agent-go/releases) 中；如果页面暂无可用版本，可使用上文的 `go install` 或从源码构建。Debian/Ubuntu 软件包安装后的命令名为 `agentlet`。

## 可以用它做什么？

以下示例使用类 POSIX Shell。请根据实际环境替换模型、接口、路径和命令。Agent 会根据任务决定是否调用工具；提示词描述的是目标，并不保证它一定采用某个固定的执行顺序。

### 1. 自主检查代码仓库

让 Agent 探索项目、运行测试、追踪失败，并生成基于证据的报告；明确要求它不要修改文件。

~~~bash
agent-go -once -prompt "检查当前仓库，运行 go test ./...，调查失败的测试，引用相关输出并报告可能原因。不要修改文件。"
~~~

适用于初步代码审计、回归问题定位、发布前检查和 Bug 复现。

### 2. 诊断 CI 与构建日志

把失败的构建日志通过管道传给 Agent，并将分析报告与诊断输出分开保存。

~~~bash
cat build.log | agent-go -pipe -prompt "分析构建日志，按根因归类失败，区分证据和推测，并列出下一步检查。" > build-report.md
~~~

日志会作为任务数据传入。必要时，Agent 也可以继续调用本地工具做补充检查。

### 3. 生产故障时间线

把故障日志整理为事件时间线、重复错误分类和有优先级的排查计划。

~~~bash
cat incident.log | agent-go -pipe -prompt "根据日志建立事件时间线，归类重复错误并引用证据，区分事实与推测，提出非破坏性的诊断命令。" > incident-report.md
~~~

在生产环境执行任何可能影响服务的命令前，请先审核建议。

### 4. 审查 Git 差异

把补丁交给 Agent 做有针对性的审查。下面的示例只要求分析，不允许修改文件。

~~~bash
git diff --no-ext-diff | agent-go -pipe -prompt "审查此差异中的正确性问题、回归风险和测试缺口。引用具体证据，不要编辑文件。" > review.md
~~~

适用于提交前审查、发布变更总结和发现测试缺口。生成的结论仍是模型分析，不能代替测试或人工审查。

### 5. 检查本地图片

通过本地图片工具，让支持视觉输入的模型分析截图、图表或故障图片。

~~~bash
agent-go -once -prompt "使用 image_read 检查 ./artifacts/failure.png。描述可见证据、可能解释，以及无法仅凭图片得出的结论。"
~~~

模型接口必须支持图片输入。agent-go 不支持音频或视频输入。

### 6. 保存大体量命令输出，供后续分析

要求 Agent 运行命令时，使用 exec 工具的 output_file 参数把完整输出保存到一个新文件，再读取日志进行分析，避免把大量输出全部塞入模型上下文。

~~~bash
agent-go -once -prompt "运行 go test ./...。使用 output_file 将完整命令输出保存到新的 test.log，检查日志并总结失败的包及可能原因。不要修改源文件。"
~~~

output_file 是模型调用工具时使用的参数，不是 CLI 命令行参数。目标文件必须不存在。标准输出与标准错误写入同一个文件，两者的先后顺序不保证。

### 7. 跨会话继续调查

在每个已完成的用户轮次或工具轮次后持久化进展，之后继续同一任务。

~~~bash
agent-go -continue incident-session.json -once -prompt "继续调查故障。回顾保存的状态，找出未解决的问题，并执行下一项非破坏性检查。"
~~~

-continue 会加载已有会话；如果文件不存在，则创建新会话，并持续保存到该文件。适用于多阶段故障调查、维护计划和跨多次运行的任务。

### 8. 批量分析目录中的日志

在 Shell 脚本中为每个文件启动一个独立 Agent 进程。下面的循环按顺序执行，并为每份日志生成单独报告。

~~~bash
mkdir -p reports
for file in logs/*.log; do
  agent-go -pipe -prompt "分析此日志，总结主要错误、引用证据，并建议下一步诊断操作。" < "$file" > "reports/$(basename "$file" .log).report.md"
done
~~~

这只是批处理工作流的基础构件。用于生产前，请补充明确的资源限制、监控和错误处理。

### 9. 非破坏性系统检查

先让 Agent 收集证据，再决定是否采取行动。

~~~bash
agent-go -once -prompt "检查当前环境，分析报告中的磁盘空间问题可能由什么引起。说明使用的命令和证据。不要删除、移动或修改任何内容。"
~~~

实际可用的命令和结果取决于操作系统、已安装工具、权限和模型的选择。

## 运行机制

1. 通过交互输入、-prompt 或 -pipe 提供目标。
2. 模型流式返回内容，并可能请求调用一个或多个工具。
3. 本地 exec 工具直接启动指定程序，并返回输出与退出状态。
4. 模型观察结果后可以继续调用工具，直到完成任务或运行被中断。
5. memory_edit 可以替换语义记忆并压缩已完成的历史；history_read 可以读取所选会话档案中的原始消息。
6. 显式指定持久化会话文件后，已完成的轮次会被保存，之后可以继续任务。

同一响应中的独立工具调用可能并行执行。存在依赖关系的步骤应放在后续工具轮次中，等待前一步结果返回后再执行。

## 内置工具

| 工具 | 用途 |
|---|---|
| exec | 使用独立参数、stdin、工作目录、环境覆盖和超时运行本地程序，返回标准输出、标准错误和退出码；可选择后台启动或将完整输出保存到新文件。 |
| image_read | 将本地图片附加给支持视觉输入的模型。 |
| memory_edit | 替换完整语义摘要，并将已完成历史移出后续提示词。已保存原文可通过 `history_read` 回读；未保存原文会丢失。 |
| history_read | 按绝对范围读取所选会话档案中的原始消息。 |

### 重要的执行语义

- exec 直接启动程序。参数分别传入；不会自动展开 Shell 变量、通配符、管道或重定向。需要 Shell 语法时，必须显式启动对应平台的 Shell。
- 前台执行需要正数 timeout 时长，例如 10s、250ms 或 1m30s。不带单位的十进制字符串（如 10）按秒解析。
- output_file 会把完整标准输出和标准错误写入工作目录下的**新文件**。若文件已存在则报错；不能与 detach 同时使用。
- detach 返回进程 ID，不等待程序结束，也不捕获输出；此时超时参数会被忽略。后续后台进程管理由调用方负责。
- -pipe 将 stdin 与可选提示词合并，并隐含 -once。助手正文写入 stdout；状态和错误写入 stderr。除文本结果外，还应检查进程退出码。
- -verbose 会将推理内容、工具参数和工具结果写入 stderr。这些详细信息可能包含任务数据，请谨慎开启。
- 会话只会写入用户明确指定的文件。-load 只读加载；-continue 加载或新建并持续保存；-save 在退出时另存到一个新文件。

## 安全边界与限制

**agent-go 不是沙箱。** exec 启动的程序拥有 Agent 进程在操作系统中的权限。子进程会继承进程环境，其中可能包含 API Key 或其他秘密信息。请使用最小权限账户、隔离不可信任务，并避免暴露任务不需要的凭据和敏感文件。

模型生成的操作应视为不可信的建议。对不熟悉的任务，先要求只读检查；执行可能造成破坏的命令前先进行审核；重要结果应独立验证。会话文件和工具输出也可能包含敏感数据。

当前运行时支持文本输入、本地图片输入、运行本地程序、整理记忆和回溯会话历史。不支持音频/视频输入或 MCP 工具服务器接入，也不提供独立的权限沙箱。

## 文档与开发

- [完整技术参考（简体中文）](docs/reference.zh-CN.md)
- [项目要求与运行约束](docs/requirements.zh-CN.md)
- [测试说明](docs/testing.md)
- [程序设计纲要](docs/program-design.zh-CN.md)
- [源代码](https://github.com/dksslq/agent-go)

本地构建与测试：

~~~bash
bash .github/test.sh
~~~

## 许可证

MIT。详见 [LICENSE](LICENSE)。