package main

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
)

func TestJournalRestartIgnoresUncommittedTailAndRepairsOnSave(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.json")
	s := newSession()
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "initial objective"})
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	first, _ := regressionReadSavedState(t, s, path)
	firstOffset := s.diskOffset
	s.Transcript = append(s.Transcript, Message{Role: "assistant", Content: "uncommitted result"})
	if result := s.editMemory("Facts from the uncommitted second checkpoint.", 0); strings.HasPrefix(result, "Error") {
		t.Fatal(result)
	}
	s.close()
	complete, err := os.ReadFile(path)
	if err != nil || len(complete) == 0 || complete[len(complete)-1] != '\n' {
		t.Fatalf("missing checkpoint commit marker: %v", err)
	}
	// Tear the write in the middle of its first member: the message and the
	// state it carried stay uncommitted together.
	cut := bytes.Index(complete, []byte("uncommitted result"))
	if cut < 0 || int64(cut) < firstOffset || cut+6 > len(complete) {
		t.Fatalf("cannot tear the document tail: %d; %d", cut, firstOffset)
	}
	interrupted := complete[:cut+6]
	if err := os.WriteFile(path, interrupted, 0o600); err != nil {
		t.Fatal(err)
	}
	restarted, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(restarted.close)
	if restarted.messageCount() != 2 || restarted.Memory != "" || restarted.diskOffset != firstOffset || !reflect.DeepEqual(restarted.Transcript, first) {
		t.Fatalf("restart exposed an uncommitted checkpoint: %+v", restarted)
	}
	afterRead, err := os.ReadFile(path)
	if err != nil || !bytes.Equal(afterRead, interrupted) {
		t.Fatalf("read-only recovery modified the interrupted source: %v", err)
	}
	replacement := Message{Role: "assistant", Content: "replacement after restart"}
	restarted.Transcript = append(restarted.Transcript, replacement)
	if err := checkpointSession(path, restarted); err != nil {
		t.Fatal(err)
	}
	restarted.close()
	messages, state := regressionReadSavedState(t, nil, path)
	want := append(append([]Message(nil), first...), replacement)
	if !reflect.DeepEqual(messages, want) || state.Count != 3 || state.Memory != "" {
		t.Fatalf("recovery did not continue exactly once: %#v; %+v", messages, state)
	}
	repaired, err := os.ReadFile(path)
	if err != nil || !bytes.HasPrefix(repaired, complete[:firstOffset]) || bytes.Contains(repaired, []byte("uncommitted result")) {
		t.Fatalf("repair changed committed bytes or retained the discarded checkpoint: %v", err)
	}
}

// The event log checks JSON structure, message ordering and commit-state
// invariants; it does not checksum every payload byte.

func TestSaveAsPreservesCompactedHistoryAndSource(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "original.json")
	copyPath := filepath.Join(dir, "copy.json")
	s := newSession()
	t.Cleanup(s.close)
	original := strings.Repeat("original raw output;", 1024)
	s.Transcript = append(s.Transcript,
		Message{Role: "user", Content: "original objective"},
		Message{Role: "assistant", ToolCalls: []ToolCall{regressionCall("exec", "exec")}},
		Message{Role: "tool", ToolCallID: "exec", Name: "exec", Content: original},
	)
	want := append([]Message(nil), s.Transcript...)
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	if result := s.editMemory("Objective and tool evidence retained.", 0); strings.HasPrefix(result, "Error") {
		t.Fatal(result)
	}
	next := Message{Role: "user", Content: "continue the objective"}
	s.Transcript = append(s.Transcript, next)
	want = append(want, next)
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	s.close()
	before, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	loaded, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(loaded.close)
	if err := checkpointSession(copyPath, loaded); err != nil {
		t.Fatal(err)
	}
	continued := Message{Role: "assistant", Content: "continued once in the copy"}
	loaded.Transcript = append(loaded.Transcript, continued)
	want = append(want, continued)
	if err := checkpointSession(copyPath, loaded); err != nil {
		t.Fatal(err)
	}
	loaded.close()
	after, err := os.ReadFile(path)
	if err != nil || !bytes.Equal(before, after) {
		t.Fatalf("save-as altered the original session: %v", err)
	}
	copied, err := os.ReadFile(copyPath)
	if err != nil || !json.Valid(copied) {
		t.Fatalf("save-as did not produce one JSON document: %v", err)
	}
	messages, state := regressionReadSavedState(t, nil, copyPath)
	if !reflect.DeepEqual(messages, want) || state.Count != len(want) || state.Cursor != 4 || state.Base != 0 {
		t.Fatalf("save-as lost or duplicated compacted history: count=%d; %+v", len(messages), state)
	}
	entries, err := os.ReadDir(dir)
	if err != nil || len(entries) != 2 || entries[0].Name() != "copy.json" || entries[1].Name() != "original.json" {
		t.Fatalf("save-as created an implicit file: %v; %v", entries, err)
	}
}

func TestLateSavedJournalKeepsBaseAcrossRestartAndCompaction(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.json")
	s := newSession()
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript,
		Message{Role: "user", Content: "discarded original objective"},
		Message{Role: "assistant", Content: "discarded original evidence"},
	)
	if result := s.editMemory("Objective and evidence retained in summary.", 0); strings.HasPrefix(result, "Error") {
		t.Fatal(result)
	}
	next := Message{Role: "user", Content: "retained subsequent objective"}
	s.Transcript = append(s.Transcript, next)
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	s.close()
	restarted, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(restarted.close)
	if err := checkpointSession(path, restarted); err != nil {
		t.Fatal(err)
	}
	if result := restarted.editMemory("Objective, evidence and subsequent work retained.", 0); strings.HasPrefix(result, "Error") {
		t.Fatal(result)
	}
	completion := Message{Role: "assistant", Content: "final completion"}
	restarted.Transcript = append(restarted.Transcript, completion)
	if err := checkpointSession(path, restarted); err != nil {
		t.Fatal(err)
	}
	restarted.close()
	messages, state := regressionReadSavedState(t, nil, path)
	if len(messages) != 3 || messages[1].Content != next.Content || messages[2].Content != completion.Content || state.Base != 2 || state.Count != 5 || state.Cursor != 4 {
		t.Fatalf("resumed late-saving journal lost its absolute base: %#v; %+v", messages, state)
	}
	loaded, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(loaded.close)
	if len(loaded.Transcript) != 2 || loaded.messageCount() != 5 || loaded.Transcript[1].Content != completion.Content || loaded.Memory != restarted.Memory {
		t.Fatalf("second restart exposed discarded history or lost retained work: %+v", loaded)
	}
}

func TestCheckpointWriteFailureLeavesOldJournalReadable(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.json")
	s := newSession()
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "retain the original objective"})
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	s.close()
	before, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	readonly, err := os.Open(path)
	if err != nil {
		t.Fatal(err)
	}
	defer readonly.Close()
	state, err := readSessionLog(readonly, nil)
	if err != nil {
		t.Fatal(err)
	}
	update := sessionUpdate{OpenDoc: state.DocOpen, Messages: []sessionMessage{
		{Index: state.Count, Message: Message{Role: "assistant", Content: "must never become visible"}},
	}}
	if offset, err := writeSessionUpdate(readonly, state.Offset, update); err == nil || offset != state.Offset {
		t.Fatalf("read-only write succeeded or changed commit offset: %d; %v", offset, err)
	}
	readonly.Close()
	after, err := os.ReadFile(path)
	if err != nil || !bytes.Equal(before, after) {
		t.Fatalf("failed write altered committed bytes: %v", err)
	}
	restarted, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(restarted.close)
	if restarted.messageCount() != 2 || restarted.Cursor != 1 || restarted.Memory != "" || restarted.Transcript[1].Content != "retain the original objective" {
		t.Fatalf("failed write changed restart state: %+v", restarted)
	}
}

func TestSessionDocumentIsAnArrayWithoutMessageIndexes(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.json")
	s := newSession()
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "objective"})
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	s.close()
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(raw, []byte("version")) || bytes.Contains(raw, []byte("\"m0\"")) {
		t.Fatalf("session contains version metadata or indexed message keys: %s", raw)
	}
	var events []json.RawMessage
	if err := json.Unmarshal(raw, &events); err != nil {
		t.Fatalf("session is not a JSON array: %v", err)
	}
	var messages []Message
	var states int
	for _, rawEvent := range events {
		var fields map[string]json.RawMessage
		if err := json.Unmarshal(rawEvent, &fields); err != nil || len(fields) != 1 {
			t.Fatalf("invalid event wrapper: %s; %v", rawEvent, err)
		}
		if body, ok := fields["message"]; ok {
			var m Message
			if err := json.Unmarshal(body, &m); err != nil {
				t.Fatal(err)
			}
			messages = append(messages, m)
			if bytes.Contains(body, []byte("\"index\"")) || bytes.Contains(body, []byte("\"m0\"")) {
				t.Fatalf("message embeds a synthetic index: %s", body)
			}
		} else if body, ok := fields["state"]; ok {
			var st sessionState
			if err := json.Unmarshal(body, &st); err != nil || st.Count != len(messages) {
				t.Fatalf("bad state checkpoint: %s; %v", body, err)
			}
			states++
		} else {
			t.Fatalf("unknown session array event: %s", rawEvent)
		}
	}
	if len(messages) != 2 || states != len(messages) {
		t.Fatalf("each standalone message should have a commit marker: messages=%d states=%d", len(messages), states)
	}
	reloaded, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(reloaded.close)
	reloaded.Transcript = append(reloaded.Transcript, Message{Role: "assistant", Content: "answer"})
	if err := checkpointSession(path, reloaded); err != nil {
		t.Fatal(err)
	}
	reloaded.close()
	raw, err = os.ReadFile(path)
	if err != nil || !json.Valid(raw) || bytes.Contains(raw, []byte("version")) || bytes.Contains(raw, []byte("\"m2\"")) {
		t.Fatalf("continued session is not the new array format: %s; %v", raw, err)
	}
	got, state := regressionReadSavedState(t, nil, path)
	if state.Count != 3 || len(got) != 3 || got[2].Content != "answer" {
		t.Fatalf("round trip lost messages: %#v; %+v", got, state)
	}
}

func TestTornFirstWriteLoadsAsEmpty(t *testing.T) {
	path := filepath.Join(t.TempDir(), "torn.json")
	s := newSession()
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "objective"})
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	s.close()
	complete, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	cut := bytes.Index(complete, []byte("\"message\""))
	if cut < 0 {
		t.Fatal("fixture lacks the system message")
	}
	if err := os.WriteFile(path, complete[:cut+4], 0o600); err != nil {
		t.Fatal(err)
	}
	if reloaded, err := loadSession(path); err != nil || reloaded != nil {
		t.Fatalf("torn first write did not load as empty: %v; %+v", err, reloaded)
	}
}
