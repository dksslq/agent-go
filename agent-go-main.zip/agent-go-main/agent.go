package main

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"sync"
	"time"
)

var (
	termRaw   bool
	termFd    int
	termOld   interface{}
	outputMu  sync.Mutex
	outputErr error

	verbose bool
)

const interruptedMarker = "[Interrupted by user]"

type interruptState struct {
	mu     sync.Mutex
	cancel context.CancelFunc
}

func (s *interruptState) set(c context.CancelFunc) {
	s.mu.Lock()
	s.cancel = c
	s.mu.Unlock()
}

func (s *interruptState) clear() {
	s.mu.Lock()
	s.cancel = nil
	s.mu.Unlock()
}

func (s *interruptState) take() context.CancelFunc {
	s.mu.Lock()
	defer s.mu.Unlock()
	c := s.cancel
	s.cancel = nil
	return c
}

var interruptMgr interruptState

type pendingState struct {
	images []ContentBlock
}

var pending pendingState

type ToolResult struct {
	StartUnix        int64       `json:"start_unix"`
	EndUnix          int64       `json:"end_unix"`
	Result           interface{} `json:"result"`
	LastRequestBytes int         `json:"last_request_bytes,omitempty"`
	HistoryNext      int         `json:"history_next,omitempty"`
}

// StreamEvent is the agent-side calling vocabulary: the inference loop consumes
// only these events. All vendor wire details (types, SSE transport, field
// mapping) live in openai.go.
type StreamEventType int

const (
	EventReasoning StreamEventType = iota
	EventToken
	EventToolCalls
	EventError
)

type StreamEvent struct {
	Type      StreamEventType
	Text      string
	ToolCalls []ToolCall
	Err       error
}

func prop(kind, description string) map[string]interface{} {
	p := map[string]interface{}{"type": kind}
	if description != "" {
		p["description"] = description
	}
	return p
}

var availableTools = []Tool{
	{Type: "function", Function: ToolDefinition{
		Name: "exec", Description: "Run a program non-interactively with piped input/output; invoke a shell explicitly for shell syntax. Parallel calls must be independent. Foreground results contain stdout, stderr and exit_code. Timeout/cancel does not roll back side effects; inspect state before retrying.",
		Parameters: map[string]interface{}{
			"type": "object", "required": []string{"program", "input", "timeout"},
			"properties": map[string]interface{}{
				"program":          prop("string", "Executable name or path on the runtime OS."),
				"args":             map[string]interface{}{"type": "array", "items": prop("string", ""), "description": "Literal arguments; no implicit shell expansion."},
				"input":            prop("string", "Stdin text followed by EOF; empty allowed."),
				"timeout":          prop("string", "Positive duration, e.g. 250ms, 10s or 1m30s; unitless decimals mean seconds. Units: ns, us/µs, ms, s, m, h. Ignored when detached."),
				"max_output_chars": prop("integer", "Unicode preview characters per stream; output continues draining. 0/omitted: full inline, or no preview with output_file."),
				"output_file":      prop("string", "New file for complete stdout+stderr bytes; relative to cwd. Existing files are rejected; stream order is unspecified. Incompatible with detach."),
				"cwd":              prop("string", "Working directory; defaults to runtime cwd."),
				"environ":          map[string]interface{}{"type": "object", "additionalProperties": prop("string", ""), "description": "Environment overrides; other variables inherited."},
				"detach":           prop("boolean", "Return a pid without waiting for completion or capturing output."),
			},
		},
	}},
	{Type: "function", Function: ToolDefinition{
		Name: "image_read", Description: "Attach a local image for a vision-capable endpoint.",
		Parameters: map[string]interface{}{"type": "object", "properties": map[string]interface{}{"path": prop("string", "Image file path; relative to runtime cwd.")}, "required": []string{"path"}},
	}},
	{Type: "function", Function: ToolDefinition{
		Name: "memory_edit", Description: "Replace the summary and compact completed history from future prompts. Preserve the goal, constraints, key facts, results, paths, and next steps. Saved originals can be read with history_read; unsaved originals are lost. Applied after the tool round's results enter the transcript.",
		Parameters: map[string]interface{}{
			"type": "object", "required": []string{"memory"},
			"properties": map[string]interface{}{
				"memory": prop("string", "Complete replacement summary: goal, constraints, key facts, results, paths, and next steps."),
				"cursor": prop("integer", "First absolute message index to keep in future prompts. Omit/0 to compact all completed history. Cannot rewind or split tool-call groups."),
			},
		},
	}},
	{Type: "function", Function: ToolDefinition{
		Name: "history_read", Description: "Read original messages from the selected session archive. Range [start,end); [0,0) returns bounds. Unavailable or unsaved messages cannot be recovered.",
		Parameters: map[string]interface{}{
			"type": "object", "required": []string{"start", "end"},
			"properties": map[string]interface{}{
				"start": prop("integer", "First absolute message index, inclusive."),
				"end":   prop("integer", "Exclusive message index; at most next."),
			},
		},
	}},
}

func parseBoolFromParams(params map[string]interface{}, key string) bool {
	v, ok := params[key].(bool)
	return ok && v
}

func parseTimeout(params map[string]interface{}) (time.Duration, error) {
	v, ok := params["timeout"].(string)
	if !ok || v == "" {
		return 0, errors.New("timeout is required and must be a nonempty duration string")
	}
	// Only decimal syntax gets a default unit. ParseDuration validates signs,
	// decimal points and range; no float conversion or overflow-prone scaling.
	if strings.Trim(v, "+-0123456789.") == "" {
		v += "s"
	}
	d, err := time.ParseDuration(v)
	if err != nil || d <= 0 {
		return 0, errors.New("timeout must be a positive duration within range; unitless decimals mean seconds")
	}
	return d, nil
}

func unquoteAllStrings(v interface{}) interface{} {
	switch x := v.(type) {
	case string:
		if unq, err := strconv.Unquote(x); err == nil {
			return unq
		}
		return x
	case []interface{}:
		for i, item := range x {
			x[i] = unquoteAllStrings(item)
		}
		return x
	case map[string]interface{}:
		for k, item := range x {
			x[k] = unquoteAllStrings(item)
		}
		return x
	}
	return v
}

func buildCmdEnv(baseEnv []string, environ map[string]string) []string {
	if len(environ) == 0 {
		return nil
	}
	// os/exec deduplicates names according to the target platform; keeping
	// overrides last handles Windows' case-insensitive environment correctly.
	envList := append([]string(nil), baseEnv...)
	for k, v := range environ {
		envList = append(envList, k+"="+v)
	}
	return envList
}

type execResult struct {
	Stdout          string `json:"stdout"`
	Stderr          string `json:"stderr"`
	ExitCode        *int   `json:"exit_code"`
	Error           string `json:"error,omitempty"`
	PID             int    `json:"pid,omitempty"`
	StdoutTruncated bool   `json:"stdout_truncated,omitempty"`
	StderrTruncated bool   `json:"stderr_truncated,omitempty"`
	OutputFile      string `json:"output_file,omitempty"`
	OutputBytes     *int64 `json:"output_bytes,omitempty"`
}

func execCmdOutput(ctx context.Context, program string, args []string, input string, timeout time.Duration, maxChars int, cwd string, environ map[string]string, detach bool, outputFile string) string {
	result := execResult{}
	finish := func() string { data, _ := json.Marshal(result); return string(data) }
	if detach && outputFile != "" {
		result.Error = "output_file is not supported with detach=true"
		return finish()
	}
	cmdCtx := ctx
	cancel := func() {}
	if !detach {
		cmdCtx, cancel = context.WithTimeout(ctx, timeout)
	}
	defer cancel()
	var cmd *exec.Cmd
	if detach {
		cmd = exec.Command(program, args...)
	} else {
		cmd = exec.CommandContext(cmdCtx, program, args...)
	}
	cmd.WaitDelay = 500 * time.Millisecond
	cmd.Stdin = strings.NewReader(input)
	cmd.Dir = cwd
	if len(environ) > 0 {
		cmd.Env = buildCmdEnv(cmd.Environ(), environ)
	}
	setSysProcAttr(cmd)
	if detach {
		if err := ctx.Err(); err != nil {
			result.Error = err.Error()
			return finish()
		}
		if err := cmd.Start(); err != nil {
			result.Error = err.Error()
			return finish()
		}
		result.PID = cmd.Process.Pid
		go cmd.Wait() // Reap the child and finish os/exec's stdin copy.
		return finish()
	}
	stdout, err := newCommandOutput(maxChars, cwd, outputFile)
	if err != nil {
		result.Error = "output file: " + err.Error()
		return finish()
	}
	stderr := &commandOutput{maxChars: maxChars, file: stdout.file}
	cmd.Stdout, cmd.Stderr = stdout, stderr
	runErr := cmd.Run()
	ctxErr := cmdCtx.Err()
	// CommandContext already cancels on timeout/interruption. Only
	// failed pipe drains need cleanup after Wait; a completed nonzero exit
	// must not signal a process-group ID that may already have been reused.
	if cmd.Process != nil && (errors.Is(runErr, exec.ErrWaitDelay) || stdout.copyErr != nil || stderr.copyErr != nil) {
		if err := cleanupCommand(cmd); err != nil && !errors.Is(err, os.ErrProcessDone) {
			runErr = errors.Join(runErr, fmt.Errorf("cancel command: %w", err))
		}
	}
	result.Stdout, result.Stderr = stdout.finish(), stderr.finish()
	result.StdoutTruncated, result.StderrTruncated = stdout.truncated, stderr.truncated
	if cmd.ProcessState != nil {
		code := cmd.ProcessState.ExitCode()
		result.ExitCode = &code
	}
	var outputErr error
	if stdout.copyErr != nil {
		outputErr = fmt.Errorf("stdout: %w", stdout.copyErr)
	}
	if stderr.copyErr != nil {
		outputErr = errors.Join(outputErr, fmt.Errorf("stderr: %w", stderr.copyErr))
	}
	if file := stdout.file; file != nil {
		outputErr = errors.Join(outputErr, file.close())
		if cmd.ProcessState == nil {
			outputErr = errors.Join(outputErr, os.Remove(file.path))
		} else {
			size := file.bytes
			result.OutputFile, result.OutputBytes = file.path, &size
		}
	}
	_, exitOnly := runErr.(*exec.ExitError)
	switch {
	case runErr != nil && errors.Is(ctxErr, context.DeadlineExceeded):
		result.Error = "command timed out"
	case runErr != nil && ctxErr != nil:
		result.Error = "command interrupted: " + ctxErr.Error()
	case runErr != nil && (!exitOnly || result.ExitCode != nil && *result.ExitCode < 0):
		result.Error = runErr.Error()
	}
	if outputErr != nil {
		if result.Error != "" {
			result.Error += "; "
		}
		result.Error += "output: " + outputErr.Error()
	}
	return finish()
}

func readImage(path string) (string, string, error) {
	info, err := os.Stat(path)
	if err != nil {
		return "", "", fmt.Errorf("open error: %v", err)
	}
	if info.IsDir() {
		return "", "", errors.New("path is a directory")
	}
	if !info.Mode().IsRegular() {
		return "", "", errors.New("image path must be a regular file")
	}
	f, err := os.Open(path)
	if err != nil {
		return "", "", fmt.Errorf("open error: %v", err)
	}
	defer f.Close()
	info, err = f.Stat()
	if err != nil {
		return "", "", fmt.Errorf("stat error: %v", err)
	}
	if !info.Mode().IsRegular() {
		return "", "", errors.New("image path must be a regular file")
	}
	data, err := io.ReadAll(f)
	if err != nil {
		return "", "", fmt.Errorf("read error: %v", err)
	}

	mimeType := http.DetectContentType(data)
	if !strings.HasPrefix(mimeType, "image/") {
		return "", "", errors.New("unsupported image file signature")
	}

	base64Str := base64.StdEncoding.EncodeToString(data)
	return fmt.Sprintf("data:%s;base64,%s", mimeType, base64Str), mimeType, nil
}

func wrapResult(startUnix, endUnix int64, result interface{}) string {
	tr := ToolResult{
		StartUnix: startUnix,
		EndUnix:   endUnix,
		Result:    result,
	}
	j, _ := json.Marshal(tr)
	return string(j)
}

func runTool(ctx context.Context, sess *Session, name, args string, toolCallID ...string) (string, *Message) {
	startTime := time.Now().Unix()
	fail := func(text string) (string, *Message) {
		var value interface{} = text
		if name == "exec" {
			value = execResult{Error: text}
		}
		return wrapResult(startTime, time.Now().Unix(), value), nil
	}

	if err := ctx.Err(); err != nil {
		return fail("tool canceled: " + err.Error())
	}
	var params map[string]interface{}
	if err := json.Unmarshal([]byte(args), &params); err != nil {
		return fail(fmt.Sprintf("Invalid arguments JSON: expected an object: %v", err))
	}

	var result interface{}
	var extraMsg *Message

	switch name {
	case "exec":
		for _, field := range []string{"unquote_arguments", "quote_result"} {
			if value, present := params[field]; present {
				if _, ok := value.(bool); !ok {
					return fail(field + " must be boolean")
				}
			}
		}
		unquoteArgs := parseBoolFromParams(params, "unquote_arguments")
		quoteResult := parseBoolFromParams(params, "quote_result")
		delete(params, "unquote_arguments")
		delete(params, "quote_result")

		if unquoteArgs {
			if m, ok := unquoteAllStrings(params).(map[string]interface{}); ok {
				params = m
			}
		}
		// Decode concrete types before launching anything. In particular, a
		// fractional/overflowed preview must not silently become unlimited.
		var checked struct {
			Program    string            `json:"program"`
			Args       []string          `json:"args"`
			Input      string            `json:"input"`
			Timeout    string            `json:"timeout"`
			MaxChars   int               `json:"max_output_chars"`
			Cwd        string            `json:"cwd"`
			Environ    map[string]string `json:"environ"`
			Detach     bool              `json:"detach"`
			OutputFile string            `json:"output_file"`
		}
		encoded, _ := json.Marshal(params)
		if err := json.Unmarshal(encoded, &checked); err != nil || checked.MaxChars < 0 {
			return fail("invalid exec parameter types or negative max_output_chars")
		}

		if checked.Program == "" {
			return fail("program is required")
		}
		var timeout time.Duration
		if !checked.Detach {
			var err error
			timeout, err = parseTimeout(params)
			if err != nil {
				return fail(err.Error())
			}
		}
		execJSON := execCmdOutput(ctx, checked.Program, checked.Args, checked.Input, timeout, checked.MaxChars, checked.Cwd, checked.Environ, checked.Detach, checked.OutputFile)
		if quoteResult {
			result = strconv.Quote(execJSON)
		} else {
			result = json.RawMessage(execJSON)
		}

	case "image_read":
		path, _ := params["path"].(string)
		dataURI, _, err := readImage(path)
		if err != nil {
			result = fmt.Sprintf("Error: %v", err)
		} else {
			result = "Image attached."
			extraMsg = &Message{
				Role: "user",
				Content: []ContentBlock{
					{Type: "text", Text: fmt.Sprintf("Image file: %q", path)},
					{Type: "image_url", ImageURL: &ImageURL{URL: dataURI, Detail: "auto"}},
				},
			}
		}

	case "memory_edit":
		var p struct {
			Memory string `json:"memory"`
			Cursor int    `json:"cursor"`
		}
		if err := json.Unmarshal([]byte(args), &p); err != nil {
			result = "Error: memory_edit requires string memory and optional integer cursor"
		} else if len(toolCallID) == 0 {
			// Direct tool tests/callers have no enclosing round to commit.
			result = sess.editMemory(p.Memory, p.Cursor)
		} else {
			result = sess.stageMemoryEdit(toolCallID[0], p.Memory, p.Cursor)
		}

	case "history_read":
		var p struct {
			Start *int `json:"start"`
			End   *int `json:"end"`
		}
		if err := json.Unmarshal([]byte(args), &p); err != nil || p.Start == nil || p.End == nil {
			result = "Error: history_read requires integer start and end"
		} else if history, err := sess.readHistory(ctx, *p.Start, *p.End); err != nil {
			result = "Error: " + err.Error()
		} else {
			result = history
		}

	default:
		endTime := time.Now().Unix()
		return wrapResult(startTime, endTime, fmt.Sprintf("Unknown tool: %q", name)), nil
	}

	endTime := time.Now().Unix()
	return wrapResult(startTime, endTime, result), extraMsg
}

func putStr(ctx context.Context, s string) error {
	if termRaw {
		s = strings.ReplaceAll(s, "\r\n", "\n")
		s = strings.ReplaceAll(s, "\n", "\r\n")
	}
	if stdoutWriter != nil {
		return stdoutWriter.write(ctx, s)
	}
	_, err := os.Stdout.WriteString(s)
	return err
}

func put(s string) {
	_ = putContext(context.Background(), s)
}

func putContext(ctx context.Context, s string) error {
	outputMu.Lock()
	defer outputMu.Unlock()
	if outputErr == nil {
		err := putStr(ctx, s)
		// A canceled turn must not poison output for the next turn.
		if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
			return err
		}
		outputErr = err
	}
	return outputErr
}

func outputFailure() error {
	outputMu.Lock()
	defer outputMu.Unlock()
	return outputErr
}

func putf(format string, args ...interface{}) {
	put(fmt.Sprintf(format, args...))
}

// infof routes operational chatter: interactive terminals see it on stdout;
// when stdin is not a terminal (piped / autonomous runs) it goes to stderr,
// keeping stdout clean for model output only.
func infof(format string, args ...interface{}) {
	_ = infofContext(context.Background(), format, args...)
}

func infofContext(ctx context.Context, format string, args ...interface{}) error {
	if termRaw {
		return putContext(ctx, fmt.Sprintf(format, args...))
	}
	text := fmt.Sprintf(format, args...)
	if stderrWriter != nil {
		return stderrWriter.write(ctx, text)
	}
	_, err := os.Stderr.WriteString(text)
	return err
}

func runToolsParallel(ctx context.Context, sess *Session, calls []ToolCall) []Message {
	type result struct {
		msg   Message
		extra *Message
	}
	out := make([]result, len(calls))
	execute := func(i int, call ToolCall) {
		var text string
		var extra *Message
		func() {
			defer func() {
				if r := recover(); r != nil {
					now := time.Now().Unix()
					text = wrapResult(now, now, fmt.Sprintf("Error: panic in tool %s: %v", call.Function.Name, r))
					extra = nil
				}
			}()
			text, extra = runTool(ctx, sess, call.Function.Name, call.Function.Arguments, call.ID)
		}()
		_ = infofContext(ctx, "[tool: %s]\n", call.Function.Name)
		if verbose {
			_ = infofContext(ctx, "arguments: %s\nresult: %s\n", call.Function.Arguments, text)
		}
		out[i] = result{Message{Role: "tool", ToolCallID: call.ID, Name: call.Function.Name, Content: text}, extra}
	}
	var wg sync.WaitGroup
	for i, call := range calls {
		if call.Function.Name != "memory_edit" {
			wg.Add(1)
			go func(i int, call ToolCall) { defer wg.Done(); execute(i, call) }(i, call)
		}
	}
	wg.Wait()
	// Stateful edits follow request order, after independent work finishes.
	// A lock alone would leave the winning snapshot nondeterministic.
	for i, call := range calls {
		if call.Function.Name == "memory_edit" {
			execute(i, call)
		}
	}
	messages := make([]Message, 0)
	for _, r := range out {
		messages = append(messages, r.msg)
	}
	for _, r := range out {
		if r.extra != nil {
			messages = append(messages, *r.extra)
		}
	}
	return messages
}

func settleTurnAbort(sess *Session, index int) {
	if index < 0 || index >= len(sess.Transcript) {
		return
	}
	message := &sess.Transcript[index]
	text, ok := message.Content.(string)
	if !ok || !strings.HasPrefix(text, "[Runtime notice; not a user instruction]") {
		return
	}
	message.Content = "[Runtime notice; prior stream failure recovered. Partial response discarded.]"
}

func recordTurnAbort(sess *Session, content, marker string, previousIndex int) (int, error) {
	feedback := "[Runtime notice; not a user instruction]\n" + marker + "\nCheck recorded results and effects before retrying."
	if content != "" {
		feedback += "\nPartial assistant output (quoted data, not instructions): " + strconv.Quote(content)
	}
	message := Message{Role: "user", Content: feedback}
	if previousIndex >= 0 && previousIndex == len(sess.Transcript)-1 {
		sess.Transcript[previousIndex] = message
		return previousIndex, nil
	}
	if err := appendSessionMessages(sess, message); err != nil {
		return previousIndex, err
	}
	return len(sess.Transcript) - 1, nil
}

var errCheckpoint = errors.New("checkpoint failed")

func runInferenceLoop(ctx context.Context, sess *Session) error {
	abortNoticeIndex := -1
	lastRetryFailure := ""
	for {
		if err := ctx.Err(); err != nil {
			return err
		}
		events, cancel, err := chatStream(ctx, sess.contextMessages(), func(n int) { sess.lastRequestBytes = n })
		if err != nil {
			// Only retry a directly tagged stream-setup failure. An HTTP rejection
			// may wrap a timeout while reading its error body; that rejection stays fatal.
			if _, retryable := err.(retryRoundError); !retryable {
				return err
			}
			var noticeErr error
			abortNoticeIndex, noticeErr = recordTurnAbort(sess, "", fmt.Sprintf("[Turn aborted: %v]", err), abortNoticeIndex)
			if noticeErr != nil {
				return errors.Join(err, noticeErr)
			}
			signature := err.Error()
			if signature == lastRetryFailure {
				return err // identical failure repeated without progress
			}
			lastRetryFailure = signature
			continue
		}
		var content strings.Builder
		var reasoning strings.Builder
		var calls []ToolCall
		var streamErr error
	loop:
		for {
			select {
			case e, ok := <-events:
				if !ok {
					streamErr = ctx.Err()
					break loop
				}
				switch e.Type {
				case EventReasoning:
					reasoning.WriteString(e.Text)
					if verbose || termRaw {
						if err := infofContext(ctx, "%s", e.Text); err != nil {
							streamErr = err
							break loop
						}
					}
				case EventToken:
					content.WriteString(e.Text)
					if err := putContext(ctx, e.Text); err != nil {
						streamErr = fmt.Errorf("write stdout: %w", err)
						break loop
					}
				case EventToolCalls:
					calls = e.ToolCalls
					break loop
				case EventError:
					streamErr = e.Err
					break loop
				}
			case <-ctx.Done():
				streamErr = ctx.Err()
				break loop
			}
		}
		cancel()
		if streamErr != nil {
			// Keep token output incremental. Since already-written bytes cannot be
			// withdrawn, delimit a partial response before any subsequent retry.
			// Respect cancellation so a blocked output destination cannot stall shutdown.
			if content.Len() > 0 {
				_ = putContext(ctx, "\n[agent-go: response interrupted; preceding output may be incomplete]\n")
			}
			marker := fmt.Sprintf("[Turn aborted: %v]", streamErr)
			if errors.Is(streamErr, context.Canceled) {
				marker = interruptedMarker
			}
			var noticeErr error
			abortNoticeIndex, noticeErr = recordTurnAbort(sess, content.String(), marker, abortNoticeIndex)
			if noticeErr != nil {
				return errors.Join(streamErr, noticeErr)
			}
			if errors.Is(streamErr, errRoundRetry) {
				signature := streamErr.Error() + "\x00" + content.String()
				if signature == lastRetryFailure {
					return streamErr // identical failure repeated without progress
				}
				lastRetryFailure = signature
				continue
			}
			return streamErr
		}
		if len(calls) == 0 {
			if content.Len() == 0 {
				err := retryRound(errors.New("API returned no assistant content or tool calls"))
				var noticeErr error
				abortNoticeIndex, noticeErr = recordTurnAbort(sess, "", fmt.Sprintf("[Turn aborted: %v]", err), abortNoticeIndex)
				if noticeErr != nil {
					return errors.Join(err, noticeErr)
				}
				signature := err.Error() + "\x00" + content.String()
				if signature == lastRetryFailure {
					return err
				}
				lastRetryFailure = signature
				continue
			}
			if err := appendSessionMessages(sess, Message{Role: "assistant", Content: content.String(), ReasoningContent: reasoning.String()}); err != nil {
				return fmt.Errorf("cannot record assistant response: %w", err)
			}
			settleTurnAbort(sess, abortNoticeIndex)
			abortNoticeIndex = -1
			if err := putContext(ctx, "\n"); err != nil {
				return fmt.Errorf("write stdout: %w", err)
			}
			return nil
		}
		if err := ctx.Err(); err != nil {
			return err
		}
		// Reserve indexes for the assistant request and every tool result,
		// including the optional extra message from each successful image read,
		// before running any external side effect.
		resultSlots, ok := addSessionInt(len(calls), len(calls))
		if !ok {
			return errors.New("tool result count overflow")
		}
		reserved, ok := addSessionInt(1, resultSlots)
		if !ok {
			return errors.New("tool round message count overflow")
		}
		if err := ensureSessionAppendFits(sess, reserved); err != nil {
			return fmt.Errorf("cannot start tool round: %w", err)
		}
		assistant := Message{Role: "assistant", ToolCalls: calls, ReasoningContent: reasoning.String()}
		if content.Len() > 0 {
			assistant.Content = content.String()
		}
		if err := appendSessionMessages(sess, assistant); err != nil {
			return fmt.Errorf("cannot record tool calls: %w", err)
		}
		results := runToolsParallel(ctx, sess, calls)
		lastRetryFailure = "" // completed tool round is progress
		// One measured input size per tool round, on new history only. Keep
		// volatile feedback out of the stable system/memory prefix.
		var last ToolResult
		if err := json.Unmarshal([]byte(results[len(calls)-1].Content.(string)), &last); err == nil {
			last.LastRequestBytes = sess.lastRequestBytes
			if sess.historyPath != "" {
				last.HistoryNext = sess.historyCount
				if sess.saveFile != "" {
					if next, ok := addSessionInt(sess.messageCount(), len(results)); ok {
						last.HistoryNext = next
					} else {
						last.HistoryNext = 0 // omit an unrepresentable advisory index
					}
				}
			}
			if encoded, err := json.Marshal(last); err == nil {
				results[len(calls)-1].Content = string(encoded)
			}
		}
		if err := appendSessionMessages(sess, results...); err != nil {
			return fmt.Errorf("cannot record tool results: %w", err)
		}
		settleTurnAbort(sess, abortNoticeIndex)
		abortNoticeIndex = -1
		memoryCheckpointed, err := sess.applyPendingMemoryEdits()
		if err != nil {
			return err
		}
		if sess.saveFile != "" && !memoryCheckpointed {
			if err := checkpointSession(sess.saveFile, sess); err != nil {
				return fmt.Errorf("%w: %w", errCheckpoint, err)
			}
		}
		if err := ctx.Err(); err != nil {
			if _, noticeErr := recordTurnAbort(sess, "", interruptedMarker, abortNoticeIndex); noticeErr != nil {
				return errors.Join(err, noticeErr)
			}
			return err
		}
	}
}

func systemRules() string {
	return "Complete authorized tasks accurately, preserve relevant state, verify outcomes, and respect stop requests."
}

func showSystemPrompt(messages []Message) {
	if !termRaw || !verbose {
		return // show internal rules only when explicitly requested
	}
	if len(messages) == 0 {
		return
	}
	if messages[0].Role != "system" {
		return
	}
	s, ok := messages[0].Content.(string)
	if !ok {
		return
	}
	put("\033[90m[system]\n" + s + "\033[0m\n\n")
}

func printHelp() {
	put("Commands:\n")
	put("  /help                 Show this help\n")
	put("  /image <path>         Append a local image for the next message\n")
	put("  /image-url <url>      Append an image URL for the next message\n")
	put("  /paste                Multiline input; Ctrl+D sends\n")
	put("  /pending              Show pending media\n")
	put("  /clear                Clear pending media\n")
	put("  /memory               Show semantic memory, cursor and context size\n")
	put("  /save <file>          Save As; close file, keep current save mode\n")
	put("  /load <file>          Load read-only; stop continuous saving\n")
	put("  /reload <file>        Alias for /load\n")
	put("  /continue <file>      Load or create; save continuously\n")
	put("  exit | quit           End session\n")
}

func buildUserMessage(text string, p *pendingState) Message {
	if len(p.images) == 0 {
		return Message{Role: "user", Content: text}
	}
	blocks := make([]ContentBlock, 0)
	if text != "" {
		blocks = append(blocks, ContentBlock{Type: "text", Text: text})
	}
	blocks = append(blocks, p.images...)
	return Message{Role: "user", Content: blocks}
}

func clearPending() {
	pending.images = nil
}

func showPending() {
	if len(pending.images) == 0 {
		put("No pending media.\n")
		return
	}
	putf("Pending images: %d\n", len(pending.images))
	for i, img := range pending.images {
		u := img.ImageURL.URL
		if len(u) > 80 {
			u = u[:80] + "..."
		}
		putf("  [%d] %s\n", i, u)
	}
}
func showMemory(s *Session) {
	count, err := s.messageCountChecked()
	if err != nil {
		putf("Cannot display session index: %v\n", err)
		return
	}
	putf("History index: %d messages | Cursor: %d | Context view: %d messages, %d bytes\n", count, s.Cursor, len(s.contextMessages()), s.contextBytes())
	if s.Memory == "" {
		put("Memory: (empty)\n")
		return
	}
	put("Memory:\n" + s.Memory + "\n")
}

// pipePrompt merges -pipe stdin data with -prompt: -prompt is the instruction,
// stdin is the payload; either alone works, both are joined with a blank line.
func pipePrompt(prompt string, stdin io.Reader) (string, error) {
	data, err := io.ReadAll(stdin)
	if err != nil {
		return "", err
	}
	p := string(data)
	switch {
	case prompt == "":
		return p, nil
	case p == "":
		return prompt, nil
	default:
		return prompt + "\n\n" + p, nil
	}
}
