package main

// A session is a JSON array of append-only events. Message positions are
// inferred from array order; message records carry no synthetic numeric key.
// Each checkpoint ends with a state event, which is the commit marker. A
// torn tail after the last state event is ignored on recovery.
import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"strings"
)

type sessionState struct {
	Base   int    `json:"base"`
	Count  int    `json:"count"`
	Cursor int    `json:"cursor"`
	Memory string `json:"memory"`
}

type sessionEvent struct {
	Message *Message      `json:"message,omitempty"`
	State   *sessionState `json:"state,omitempty"`
}

type sessionMessage struct {
	Index   int
	Message Message
}

type sessionLogState struct {
	Base        int
	Count       int // absolute exclusive history bound
	StoredCount int // number of message events physically present
	Cursor      int
	Memory      string
	Offset      int64 // byte immediately after the last committed state event
	DocOpen     bool
}

type sessionUpdate struct {
	OpenDoc  bool
	Messages []sessionMessage
	// StreamCount and StreamAt let snapshots expose their resident transcript
	// as an indexed source, without allocating a second O(history) message slice.
	// A streamed source is read first for full validation and again for writing.
	StreamCount int
	StreamAt    func(int) (sessionMessage, error)
	State       *sessionState
	// Prior is the session's last committed metadata. Supplying it avoids
	// rescanning the entire ever-growing archive on every append.
	Prior *sessionLogState
}

func (u sessionUpdate) messageCount() (int, error) {
	if u.StreamAt != nil {
		if len(u.Messages) != 0 || u.StreamCount < 0 {
			return 0, errors.New("invalid streamed session update")
		}
		return u.StreamCount, nil
	}
	if u.StreamCount != 0 {
		return 0, errors.New("stream count supplied without a message source")
	}
	return len(u.Messages), nil
}

func (u sessionUpdate) messageAt(index int) (sessionMessage, error) {
	if u.StreamAt != nil {
		if index < 0 || index >= u.StreamCount {
			return sessionMessage{}, errors.New("streamed session index outside range")
		}
		return u.StreamAt(index)
	}
	if index < 0 || index >= len(u.Messages) {
		return sessionMessage{}, errors.New("session update index outside range")
	}
	return u.Messages[index], nil
}

func sessionIntMaxValue() int { return int(^uint(0) >> 1) }

func addSessionInt(a, b int) (int, bool) {
	if a < 0 || b < 0 || a > sessionIntMaxValue()-b {
		return 0, false
	}
	return a + b, true
}

func docReadErr(err error) error {
	if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
		return nil
	}
	// encoding/json reports truncated values as SyntaxError, not io.ErrUnexpectedEOF.
	var syntaxErr *json.SyntaxError
	if errors.As(err, &syntaxErr) && syntaxErr.Error() == "unexpected end of JSON input" {
		return nil
	}
	return err
}

func readSessionLog(f *os.File, visit func(int, Message) error) (sessionLogState, error) {
	var state sessionLogState
	info, err := f.Stat()
	if err != nil {
		return state, err
	}
	if !info.Mode().IsRegular() {
		return state, errors.New("session must be a regular file")
	}
	return readSessionLogPrefix(f, info.Size(), visit)
}

// readSessionLogPrefix reads a fixed prefix, so snapshot copying never observes
// bytes appended after the copy operation began. The final closing bracket is
// deliberately not required: writers commit each update at its state event.
func readSessionLogPrefix(f *os.File, size int64, visit func(int, Message) error) (sessionLogState, error) {
	var state sessionLogState
	if size < 0 {
		return state, errors.New("invalid session size")
	}
	if size == 0 {
		return state, nil
	}
	d := json.NewDecoder(io.NewSectionReader(f, 0, size))
	open, err := d.Token()
	if err != nil {
		return state, fmt.Errorf("invalid session JSON array: %w", err)
	}
	if open != json.Delim('[') {
		return state, errors.New("session must be a JSON array")
	}

	var pending []Message
	storedCount := 0
	closedArray := false
	var validator transcriptValidator
	seenState := false
	committedGap := false
	base := 0
	var lastState sessionLogState
	incompleteTail := false

	for d.More() {
		var raw json.RawMessage
		if err := d.Decode(&raw); err != nil {
			if docReadErr(err) == nil {
				incompleteTail = true
				break
			}
			return lastState, fmt.Errorf("invalid session event: %w", err)
		}
		eventEnd := d.InputOffset()
		event, err := decodeSessionEvent(raw)
		if err != nil {
			return lastState, fmt.Errorf("invalid session event: %w", err)
		}
		if event.Message != nil {
			if len(pending) > 0 {
				first := pending[0]
				expected, ok := addSessionInt(1, len(first.ToolCalls))
				if !ok {
					return lastState, errors.New("tool-call group size overflow")
				}
				if len(pending) >= expected {
					return lastState, errors.New("missing state commit after a complete message group")
				}
			}
			pending = append(pending, *event.Message)
			continue
		}
		if event.State == nil {
			return lastState, errors.New("session event must contain a message or state")
		}

		st := *event.State
		total, ok := addSessionInt(storedCount, len(pending))
		if !ok {
			return lastState, errors.New("session message count overflow")
		}
		if st.Base < 0 || st.Count < 1 || st.Cursor <= st.Base || st.Cursor > st.Count {
			return lastState, errors.New("session state has an invalid base, count, or cursor")
		}
		gap := false
		switch {
		case st.Base == 0 && st.Count == total:
			gap = false
		case st.Base > 0:
			withGap, ok := addSessionInt(st.Base, total)
			if !ok || st.Count != withGap {
				return lastState, errors.New("session state count does not match its message array")
			}
			gap = true
		default:
			return lastState, errors.New("session state count does not match its message array")
		}
		if seenState {
			if st.Base != base {
				return lastState, errors.New("session base changed within one file")
			}
			if gap != committedGap {
				return lastState, errors.New("session history gap changed within one file")
			}
			if st.Count < lastState.Count || st.Cursor < lastState.Cursor {
				return lastState, errors.New("session state moved backwards")
			}
		}
		if (st.Base > 0 || st.Cursor-st.Base > 1) && strings.TrimSpace(st.Memory) == "" {
			return lastState, errors.New("compacted session requires semantic memory")
		}

		// The event after a state marker is not committed until another state
		// marker arrives. Validate and publish only this complete batch.
		for i, message := range pending {
			if err := validator.add(message); err != nil {
				return lastState, err
			}
			position, ok := addSessionInt(storedCount, i)
			if !ok {
				return lastState, errors.New("session message index overflow")
			}
			index := position
			if gap && position > 0 {
				index, ok = addSessionInt(st.Base, position)
				if !ok {
					return lastState, errors.New("absolute session index overflow")
				}
			}
			if index == st.Cursor && message.Role == "tool" {
				return lastState, errors.New("session cursor splits a tool-call group")
			}
			if visit != nil {
				if err := visit(index, message); err != nil {
					return lastState, err
				}
			}
		}
		if err := validator.finish(); err != nil {
			return lastState, err
		}
		// Drop map buckets from a completed, potentially very large parallel
		// tool group before parsing the next archive record.
		validator.pending = nil
		storedCount = total
		base = st.Base
		committedGap = gap
		seenState = true
		lastState = sessionLogState{
			Base:        st.Base,
			Count:       st.Count,
			StoredCount: storedCount,
			Cursor:      st.Cursor,
			Memory:      st.Memory,
			Offset:      eventEnd,
			DocOpen:     true,
		}
		state = lastState
		for i := range pending {
			pending[i] = Message{}
		}
		pending = nil
	}

	if !incompleteTail {
		closing, closeErr := d.Token()
		if closeErr == nil {
			if closing != json.Delim(']') {
				return lastState, errors.New("invalid session JSON array terminator")
			}
			closedArray = true
			if _, err := d.Token(); err == nil || !errors.Is(err, io.EOF) {
				return lastState, errors.New("trailing data after session JSON array")
			}
		} else if err := docReadErr(closeErr); err != nil {
			return lastState, fmt.Errorf("invalid session JSON array: %w", err)
		}
	}
	if !seenState {
		if !closedArray {
			// A process may exit before the first state event commits. Treat
			// that partial new file as empty; continue mode will report it as
			// an empty/incomplete existing session rather than invent history.
			return state, nil
		}
		return state, errors.New("session contains no committed checkpoint")
	}
	// Any pending messages after the final state are an uncommitted tail.
	return lastState, nil
}

func decodeSessionEvent(data []byte) (sessionEvent, error) {
	var event sessionEvent
	var message json.RawMessage
	var state json.RawMessage
	seen, err := decodeSessionObject(data, func(key string, d *json.Decoder) error {
		switch key {
		case "message":
			return d.Decode(&message)
		case "state":
			return d.Decode(&state)
		default:
			return fmt.Errorf("unknown session event field %q", key)
		}
	})
	if err != nil {
		return event, err
	}
	if len(seen) != 1 {
		return event, errors.New("session event must contain exactly one field")
	}
	if raw, ok := seen["message"]; ok {
		if !raw || bytes.Equal(bytes.TrimSpace(message), []byte("null")) {
			return event, errors.New("session message event cannot be null")
		}
		var m Message
		if err := json.Unmarshal(message, &m); err != nil {
			return event, err
		}
		event.Message = &m
		return event, nil
	}
	if raw, ok := seen["state"]; ok {
		if !raw || bytes.Equal(bytes.TrimSpace(state), []byte("null")) {
			return event, errors.New("session state event cannot be null")
		}
		var st sessionState
		if err := json.Unmarshal(state, &st); err != nil {
			return event, err
		}
		event.State = &st
		return event, nil
	}
	return event, errors.New("empty session event")
}

func decodeSessionObject(data []byte, field func(string, *json.Decoder) error) (map[string]bool, error) {
	d := json.NewDecoder(bytes.NewReader(data))
	first, err := d.Token()
	if err != nil || first != json.Delim('{') {
		return nil, errors.New("expected a JSON object")
	}
	seen := make(map[string]bool)
	for d.More() {
		key, err := d.Token()
		if err != nil {
			return nil, err
		}
		name, ok := key.(string)
		if !ok || seen[name] {
			return nil, errors.New("invalid or duplicate session field")
		}
		seen[name] = true
		if err := field(name, d); err != nil {
			return nil, err
		}
	}
	if end, err := d.Token(); err != nil || end != json.Delim('}') {
		return nil, errors.New("invalid session object")
	}
	if _, err := d.Token(); err != io.EOF {
		return nil, errors.New("trailing data in session object")
	}
	return seen, nil
}

// writeSessionUpdate appends a batch followed by a state event. The returned
// offset points after the state event and before the array terminator, so a
// failed append can be rolled back without losing the last committed state.
func writeSessionUpdate(f *os.File, offset int64, update sessionUpdate) (int64, error) {
	updateCount, sourceErr := update.messageCount()
	if sourceErr != nil {
		return offset, sourceErr
	}
	if updateCount == 0 && update.State == nil {
		return offset, nil
	}
	info, err := f.Stat()
	if err != nil {
		return offset, err
	}
	if !info.Mode().IsRegular() || offset < 0 || offset > info.Size() {
		return offset, errors.New("invalid checkpoint file or offset")
	}
	if offset == 0 && info.Size() != 0 {
		return offset, errors.New("nonempty session has no committed offset")
	}

	var current sessionLogState
	if offset > 0 {
		if update.Prior != nil {
			current = *update.Prior
			if current.Offset != offset || current.Count < 1 || current.Base < 0 ||
				current.StoredCount < 1 || current.Count < current.Base || current.Count-current.Base != current.StoredCount {
				return offset, errors.New("invalid prior checkpoint metadata")
			}
			var last [1]byte
			if _, err := f.ReadAt(last[:], offset-1); err != nil || last[0] != '}' {
				return offset, errors.New("checkpoint offset is not at a committed state event")
			}
		} else {
			current, err = readSessionLogPrefix(f, offset, nil)
			if err != nil {
				return offset, err
			}
			if current.Offset != offset {
				return offset, errors.New("checkpoint offset is not at a committed state event")
			}
		}
	}

	base := current.Base
	if update.State != nil {
		base = update.State.Base
	}
	if base < 0 {
		return offset, errors.New("negative session base")
	}
	if current.Count > 0 && base != current.Base {
		return offset, errors.New("session base cannot change after the first checkpoint")
	}

	finalCount := current.Count
	if updateCount > 0 {
		var ok bool
		if current.Count == 0 {
			finalCount, ok = addSessionInt(base, updateCount)
		} else {
			finalCount, ok = addSessionInt(current.Count, updateCount)
		}
		if !ok || finalCount == 0 {
			return offset, errors.New("session message count overflow")
		}
	}
	nextState := sessionState{Base: base, Count: finalCount, Cursor: current.Cursor, Memory: current.Memory}
	if update.State != nil {
		nextState = *update.State
		if nextState.Count != finalCount {
			return offset, errors.New("checkpoint state count does not match appended messages")
		}
	}
	if nextState.Cursor <= nextState.Base || nextState.Cursor > nextState.Count {
		return offset, errors.New("checkpoint cursor outside saved history")
	}
	if current.Count > 0 && nextState.Cursor < current.Cursor {
		return offset, errors.New("checkpoint cursor cannot move backwards")
	}
	if (nextState.Base > 0 || nextState.Cursor-nextState.Base > 1) && strings.TrimSpace(nextState.Memory) == "" {
		return offset, errors.New("compacted session requires semantic memory")
	}

	// Validate the entire update before modifying the file, and split it only
	// at complete tool-call groups. This lets a very large snapshot commit and
	// recover in bounded chunks rather than buffering the entire transcript.
	validator := transcriptValidator{count: current.StoredCount}
	if current.Count == 0 {
		validator.count = 0
	}
	for i := 0; i < updateCount; {
		first, sourceErr := update.messageAt(i)
		if sourceErr != nil {
			return offset, sourceErr
		}
		end := i + 1
		if len(first.Message.ToolCalls) > 0 {
			if first.Message.Role != "assistant" {
				return offset, errors.New("tool calls attached to a non-assistant message")
			}
			if len(first.Message.ToolCalls) > updateCount-end {
				return offset, errors.New("checkpoint ends inside a tool-call group")
			}
			end += len(first.Message.ToolCalls)
		}
		for j := i; j < end; j++ {
			item, sourceErr := update.messageAt(j)
			if sourceErr != nil {
				return offset, sourceErr
			}
			var expected int
			var ok bool
			if current.Count > 0 {
				expected, ok = addSessionInt(current.Count, j)
			} else if j == 0 {
				expected, ok = 0, true
			} else {
				expected, ok = addSessionInt(base, j)
			}
			if !ok {
				return offset, errors.New("absolute session index overflow")
			}
			if item.Index != expected {
				return offset, fmt.Errorf("non-contiguous session update: got index %d, want %d", item.Index, expected)
			}
			if err := validator.add(item.Message); err != nil {
				return offset, err
			}
		}
		if err := validator.finish(); err != nil {
			return offset, err
		}
		validator.pending = nil
		i = end
	}
	if updateCount == 0 {
		if current.Count == 0 {
			return offset, errors.New("cannot commit a session state before the first message")
		}
		if err := validator.finish(); err != nil {
			return offset, err
		}
	}

	offsetLimit := int64(^uint64(0) >> 1)
	written := int64(0)
	writeBytes := func(p []byte) error {
		if int64(len(p)) > offsetLimit-offset-written {
			return errors.New("session file offset overflow")
		}
		n, err := f.Write(p)
		written += int64(n)
		if err != nil {
			return err
		}
		if n != len(p) {
			return io.ErrShortWrite
		}
		return nil
	}
	rollback := func(cause error) (int64, error) {
		truncateErr := f.Truncate(offset)
		var closeErr error
		if truncateErr == nil && offset > 0 {
			if _, err := f.Seek(offset, io.SeekStart); err != nil {
				closeErr = err
			} else {
				closing := []byte("\n]\n")
				n, err := f.Write(closing)
				if err == nil && n != len(closing) {
					err = io.ErrShortWrite
				}
				closeErr = err
			}
		}
		_, seekErr := f.Seek(offset, io.SeekStart)
		syncErr := f.Sync()
		if err := errors.Join(truncateErr, closeErr, seekErr, syncErr); err != nil {
			cause = errors.Join(cause, fmt.Errorf("rollback checkpoint: %w", err))
		}
		return offset, cause
	}
	if err := f.Truncate(offset); err != nil {
		return rollback(err)
	}
	if _, err := f.Seek(offset, io.SeekStart); err != nil {
		return rollback(err)
	}
	if offset == 0 {
		if err := writeBytes([]byte("[")); err != nil {
			return rollback(err)
		}
	}

	writeEvent := func(event sessionEvent, first bool) error {
		raw, err := json.Marshal(event)
		if err != nil {
			return err
		}
		separator := ",\n  "
		if first {
			separator = "\n  "
		}
		if err := writeBytes([]byte(separator)); err != nil {
			return err
		}
		return writeBytes(raw)
	}
	writeState := func(count, cursor int, memory string, first bool) error {
		state := sessionState{Base: base, Count: count, Cursor: cursor, Memory: memory}
		if state.Cursor <= state.Base || state.Cursor > state.Count {
			return errors.New("checkpoint cursor outside saved history")
		}
		if (state.Base > 0 || state.Cursor-state.Base > 1) && strings.TrimSpace(state.Memory) == "" {
			return errors.New("compacted session requires semantic memory")
		}
		if err := writeEvent(sessionEvent{State: &state}, first); err != nil {
			return err
		}
		return f.Sync()
	}

	firstEvent := offset == 0
	committedOffset := offset
	previousCursor := current.Cursor
	if current.Count == 0 {
		var ok bool
		previousCursor, ok = addSessionInt(base, 1)
		if !ok {
			return rollback(errors.New("session cursor overflow"))
		}
	}
	batchStart := 0
	commitBatch := func(processed int) error {
		if processed <= batchStart {
			return nil
		}
		var count int
		var ok bool
		if current.Count > 0 {
			count, ok = addSessionInt(current.Count, processed)
		} else {
			count, ok = addSessionInt(base, processed)
		}
		if !ok {
			return errors.New("session message count overflow")
		}
		// Intermediate commits only publish the appended messages. Keep the
		// previously committed cursor/memory until the whole requested update
		// has been written; a crash must not compact messages still in flight.
		commitMemory := current.Memory
		if current.Count == 0 {
			commitMemory = nextState.Memory
		}
		if err := writeState(count, previousCursor, commitMemory, firstEvent); err != nil {
			return err
		}
		firstEvent = false
		committedOffset = offset + written
		batchStart = processed
		return nil
	}
	processed := 0
	for processed < updateCount {
		first, sourceErr := update.messageAt(processed)
		if sourceErr != nil {
			return rollback(sourceErr)
		}
		end := processed + 1
		if len(first.Message.ToolCalls) > 0 {
			end += len(first.Message.ToolCalls)
		}
		for i := processed; i < end; i++ {
			item, sourceErr := update.messageAt(i)
			if sourceErr != nil {
				return rollback(sourceErr)
			}
			message := item.Message
			if err := writeEvent(sessionEvent{Message: &message}, firstEvent); err != nil {
				return rollback(err)
			}
			firstEvent = false
		}
		processed = end
		if err := commitBatch(processed); err != nil {
			return rollback(err)
		}
	}
	if batchStart < processed {
		if err := commitBatch(processed); err != nil {
			return rollback(err)
		}
	}
	commitMemory := current.Memory
	if current.Count == 0 {
		commitMemory = nextState.Memory
	}
	if updateCount == 0 || nextState.Cursor != previousCursor || nextState.Memory != commitMemory {
		if err := writeState(finalCount, nextState.Cursor, nextState.Memory, firstEvent); err != nil {
			return rollback(err)
		}
		committedOffset = offset + written
	}
	if err := writeBytes([]byte("\n]\n")); err != nil {
		return rollback(err)
	}
	if err := f.Sync(); err != nil {
		return rollback(err)
	}
	return committedOffset, nil
}
