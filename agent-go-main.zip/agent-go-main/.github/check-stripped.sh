#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -eq 0 ]; then
  echo 'Usage: check-stripped.sh binary [...]' >&2
  exit 1
fi
for binary in "$@"; do
  # Reject unreadable/non-Go files before interpreting nm's expected failure.
  metadata=$(go version -m "$binary")
  case "$metadata" in
    *'CGO_ENABLED=0'*) ;;
    *) printf 'CGO_ENABLED=0 missing: %s\n' "$binary" >&2; exit 1 ;;
  esac
  case "$metadata" in
    *'-trimpath=true'*) ;;
    *) printf 'trimpath missing: %s\n' "$binary" >&2; exit 1 ;;
  esac
  build_id=$(go tool buildid "$binary")
  if [ -n "$build_id" ]; then
    printf 'Unexpected Go build ID: %s\n' "$binary" >&2
    exit 1
  fi
  if symbols=$(go tool nm "$binary" 2>&1); then
    # Mach-O keeps undefined dynamic imports required by the system linker.
    case "$metadata" in
      *'GOOS=darwin'*)
        if ! printf '%s\n' "$symbols" | awk 'NF && !(NF == 2 && $1 == "U") { bad=1 } END { exit bad }'; then
          printf 'Unexpected defined symbols: %s\n' "$binary" >&2
          exit 1
        fi ;;
      *) printf 'Unexpected symbol table: %s\n' "$binary" >&2; exit 1 ;;
    esac
  else
    case "$symbols" in
      *'no symbol section'*|*'no symbols'*) ;;
      *) printf '%s\n' "$symbols" >&2; exit 1 ;;
    esac
  fi
  printf 'Stripped: %s\n' "$binary"
done
