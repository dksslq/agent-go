#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

unformatted=$(gofmt -l .)
if [ -n "$unformatted" ]; then
  printf 'Run gofmt on:\n%s\n' "$unformatted" >&2
  exit 1
fi
go vet ./...
# Additional flags may select coverage output or individual regression tests.
CGO_ENABLED=1 go test -count=1 -race -shuffle=on -gcflags=all=-d=checkptr=2 -timeout=6m "$@" ./...
