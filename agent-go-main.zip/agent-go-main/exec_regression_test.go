package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestParseTimeoutFractionalAndOverflow(t *testing.T) {
	valid := map[string]time.Duration{
		"10": 10 * time.Second, "0.125": 125 * time.Millisecond,
		"+2": 2 * time.Second, ".5": 500 * time.Millisecond, "1.": time.Second,
		"250ms": 250 * time.Millisecond, "1m30s": 90 * time.Second,
		"1ns": time.Nanosecond, "1us": time.Microsecond, "1µs": time.Microsecond,
		"1μs": time.Microsecond, "1h": time.Hour,
		"0.000000001":           time.Nanosecond,
		"9223372036854775807ns": time.Duration(1<<63 - 1),
		"9223372036.854775807":  time.Duration(1<<63 - 1),
	}
	for input, want := range valid {
		d, err := parseTimeout(map[string]interface{}{"timeout": input})
		if err != nil || d != want {
			t.Errorf("%q = %v, %v; want %v", input, d, err, want)
		}
	}
	for _, v := range []interface{}{nil, 10.0, true, "", "0", "0s", "-1", "-1ms", "0.1ns", "0.0000000001", "9223372036854775808ns", "9223372036.854775808", "1e3", "NaN", "Inf", " 10", "10 ", ".", "+", "1..2", "1s2", "1d", math.NaN(), math.Inf(1)} {
		if _, err := parseTimeout(map[string]interface{}{"timeout": v}); err == nil {
			t.Errorf("accepted invalid timeout %v", v)
		}
	}
}

func TestCommandOutputSplitUTF8AndDiscard(t *testing.T) {
	out, err := newCommandOutput(2, "", "")
	if err != nil {
		t.Fatal(err)
	}
	for _, chunk := range [][]byte{{0xe4}, {0xbd, 0xa0, 0xe5}, {0xa5}, {0xbd}, []byte(strings.Repeat("x", 100000))} {
		if n, err := out.Write(chunk); err != nil || n != len(chunk) {
			t.Fatalf("Write = %d, %v", n, err)
		}
	}
	result := out.finish()
	if !out.truncated || result != "你好" {
		t.Fatalf("split UTF-8 preview = %q, %v", result, err)
	}
	if out.buffer.Len() != len("你好") || len(out.pending) != 0 {
		t.Fatalf("discarded output retained: %d buffered, %d pending", out.buffer.Len(), len(out.pending))
	}
}

func TestCommandOutputIncompleteAndInvalidUTF8(t *testing.T) {
	for _, tc := range []struct {
		chunks [][]byte
		limit  int
		want   string
	}{
		{[][]byte{{0xe4}, {'a', 'b'}}, 2, "\xe4a"},
		{[][]byte{{0xe4, 0xbd}}, 1, "\xe4"},
		{[][]byte{[]byte("你好")}, 2, "你好"},
	} {
		out, _ := newCommandOutput(tc.limit, "", "")
		for _, p := range tc.chunks {
			out.Write(p)
		}
		got := out.finish()
		if got != tc.want {
			t.Fatalf("preview = %q, %v; want %q", got, nil, tc.want)
		}
	}
}

// TestExecCaptureHelperProcess supplies portable child behavior for exec tests.
func TestExecCaptureHelperProcess(t *testing.T) {
	if os.Getenv("AGENT_GO_EXEC_HELPER") != "1" {
		return
	}
	args := os.Args
	for len(args) > 0 && args[0] != "--" {
		args = args[1:]
	}
	if len(args) != 2 {
		os.Exit(2)
	}
	if _, err := os.Stdout.WriteString(strings.Repeat("x", 100000)); err != nil {
		os.Exit(3)
	}
	if err := os.WriteFile(args[1], []byte("complete"), 0600); err != nil {
		os.Exit(4)
	}
	os.Exit(7)
}

func TestExecEnvironmentHelperProcess(t *testing.T) {
	if os.Getenv("AGENT_GO_ENV_HELPER") != "1" {
		return
	}
	fmt.Printf("PWD=%s\nINJECTED=%s\n", os.Getenv("PWD"), os.Getenv("AGENT_GO_INJECTED"))
	os.Exit(0)
}

func TestExecEnvironmentUsesWorkingDirectory(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("PWD is a Unix environment convention")
	}
	dir := t.TempDir()
	result := execCmd(context.Background(), os.Args[0], []string{"-test.run=^TestExecEnvironmentHelperProcess$"}, "", 5*time.Second, 0, dir, map[string]string{"AGENT_GO_ENV_HELPER": "1", "AGENT_GO_INJECTED": "yes"}, false)
	if !strings.Contains(decodeExecResult(t, result).Stdout, "PWD="+dir+"\n") || !strings.Contains(decodeExecResult(t, result).Stdout, "INJECTED=yes\n") {
		t.Fatalf("injected environment lost working directory: %q", result)
	}
	result = execCmd(context.Background(), os.Args[0], []string{"-test.run=^TestExecEnvironmentHelperProcess$"}, "", 5*time.Second, 0, dir, map[string]string{"AGENT_GO_ENV_HELPER": "1", "PWD": "explicit"}, false)
	if !strings.Contains(decodeExecResult(t, result).Stdout, "PWD=explicit\n") {
		t.Fatalf("explicit PWD override was lost: %q", result)
	}
}

func captureHelperArgs(marker string) []string {
	return []string{"-test.run=^TestExecCaptureHelperProcess$", "--", marker}
}

func TestExecOutputLimitDrainsAndPreservesStatus(t *testing.T) {
	marker := filepath.Join(t.TempDir(), "finished")
	result := execCmd(context.Background(), os.Args[0], captureHelperArgs(marker), "", 5*time.Second, 20, "", map[string]string{"AGENT_GO_EXEC_HELPER": "1"}, false)
	if _, err := os.Stat(marker); err != nil {
		t.Fatalf("output limit terminated the command: %v; result %q", err, result)
	}
	parsed := decodeExecResult(t, result)
	if parsed.Stdout != strings.Repeat("x", 20) || !parsed.StdoutTruncated || parsed.ExitCode == nil || *parsed.ExitCode != 7 {
		t.Fatalf("preview lost output or exit status: %q", result)
	}
}

func TestExecOutputFilePreservesRawBytesAndExistingFiles(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "output")
	marker := filepath.Join(dir, "finished")
	result := execCmdOutput(context.Background(), os.Args[0], captureHelperArgs(marker), "", 5*time.Second, 10, dir, map[string]string{"AGENT_GO_EXEC_HELPER": "1"}, false, "output")
	data, err := os.ReadFile(path)
	if err != nil || string(data) != strings.Repeat("x", 100000) {
		t.Fatalf("raw output not retained: %d bytes, %v", len(data), err)
	}
	parsed := decodeExecResult(t, result)
	if parsed.OutputFile != path || parsed.OutputBytes == nil || *parsed.OutputBytes != 100000 || parsed.Stdout != strings.Repeat("x", 10) || !parsed.StdoutTruncated || parsed.ExitCode == nil || *parsed.ExitCode != 7 {
		t.Fatalf("file result missing preview/status: %q", result)
	}
	if runtime.GOOS != "windows" {
		st, err := os.Stat(path)
		if err != nil || st.Mode().Perm() != 0600 {
			t.Fatalf("output permissions: %v, %v", st, err)
		}
	}
	result = execCmdOutput(context.Background(), os.Args[0], captureHelperArgs(marker), "", 5*time.Second, 0, dir, nil, false, "output")
	if decodeExecResult(t, result).Error == "" {
		t.Fatalf("existing output file accepted: %q", result)
	}
	after, err := os.ReadFile(path)
	if err != nil || string(after) != string(data) {
		t.Fatal("existing output file changed")
	}
}

func TestCommandOutputFileWithoutPreview(t *testing.T) {
	path := filepath.Join(t.TempDir(), "output")
	out, err := newCommandOutput(0, "", path)
	if err != nil {
		t.Fatal(err)
	}
	out.Write([]byte("raw\x00bytes\xff"))
	result := out.finish()
	err = out.file.close()
	if err != nil || out.buffer.Len() != 0 || strings.Contains(result, "raw") {
		t.Fatalf("file-only output retained inline: %q, %v", result, err)
	}
	data, err := os.ReadFile(path)
	if err != nil || string(data) != "raw\x00bytes\xff" {
		t.Fatalf("file-only output = %q, %v", data, err)
	}
}

func TestExecCancelKillsGrandchildren(t *testing.T) {
	if runtime.GOOS != "linux" && runtime.GOOS != "darwin" {
		t.Skip("Unix process-group regression")
	}
	for _, cancelParent := range []bool{false, true} {
		t.Run(fmt.Sprintf("parentCancel=%v", cancelParent), func(t *testing.T) {
			dir := t.TempDir()
			ready := filepath.Join(dir, "ready")
			leaked := filepath.Join(dir, "leaked")
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			timeout := 150 * time.Millisecond
			if cancelParent {
				timeout = 5 * time.Second
			}
			done := make(chan string, 1)
			go func() {
				done <- execCmd(ctx, "sh", []string{"-c", `sh -c 'printf ready > "$1"; sleep 1; printf leaked > "$2"' sh "$1" "$2" & wait`, "sh", ready, leaked}, "", timeout, 0, "", nil, false)
			}()
			if cancelParent {
				deadline := time.Now().Add(2 * time.Second)
				for {
					if _, err := os.Stat(ready); err == nil {
						break
					}
					if time.Now().After(deadline) {
						t.Fatal("child did not become ready")
					}
					time.Sleep(10 * time.Millisecond)
				}
				cancel()
			}
			select {
			case result := <-done:
				want := "timed out"
				if cancelParent {
					want = "interrupted"
				}
				if !strings.Contains(result, want) {
					t.Fatalf("cancel status = %q; want %q", result, want)
				}
			case <-time.After(2 * time.Second):
				t.Fatal("cancel did not return")
			}
			time.Sleep(1100 * time.Millisecond)
			if _, err := os.Stat(leaked); !os.IsNotExist(err) {
				t.Fatalf("grandchild survived cancellation: %v", err)
			}
		})
	}
}

func TestExecExitedParentDoesNotLeavePipeHoldingChild(t *testing.T) {
	if runtime.GOOS != "linux" && runtime.GOOS != "darwin" {
		t.Skip("Unix process-group regression")
	}
	for _, tc := range []struct {
		timeout time.Duration
		exit    string
	}{
		{100 * time.Millisecond, ""},
		{5 * time.Second, ""},
		{5 * time.Second, " exit 9"},
	} {
		t.Run(tc.timeout.String()+tc.exit, func(t *testing.T) {
			marker := filepath.Join(t.TempDir(), "leaked")
			result := execCmd(context.Background(), "sh", []string{"-c", `sh -c 'sleep 1; printf leaked > "$1"' sh "$1" &` + tc.exit, "sh", marker}, "", tc.timeout, 0, "", nil, false)
			if decodeExecResult(t, result).Error == "" {
				t.Fatalf("pipe drain failure was hidden: %q", result)
			}
			time.Sleep(1100 * time.Millisecond)
			if _, err := os.Stat(marker); !os.IsNotExist(err) {
				t.Fatalf("pipe-holding child survived: %v", err)
			}
		})
	}
}

func TestExecDetachedProcessIsReaped(t *testing.T) {
	if runtime.GOOS != "linux" {
		t.Skip("Linux /proc verifies that exited children are reaped")
	}
	result := execCmd(context.Background(), "sh", []string{"-c", "exit 0"}, "", time.Second, 0, "", nil, true)
	pid := decodeExecResult(t, result).PID
	if pid <= 0 {
		t.Fatalf("detach result: %q", result)
	}
	deadline := time.Now().Add(2 * time.Second)
	path := filepath.Join("/proc", strconv.Itoa(pid))
	for {
		if _, err := os.Stat(path); os.IsNotExist(err) {
			return
		}
		if time.Now().After(deadline) {
			t.Fatalf("detached child %d remains after exit", pid)
		}
		time.Sleep(10 * time.Millisecond)
	}
}

func decodeExecResult(t *testing.T, text string) execResult {
	t.Helper()
	var result execResult
	if err := json.Unmarshal([]byte(text), &result); err != nil {
		t.Fatal(err)
	}
	return result
}
