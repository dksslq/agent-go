package main

import (
	"bytes"
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSessionArrayAppendAndReload(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.json")
	s := newSession()
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "objective"})
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	s.Transcript = append(s.Transcript, Message{Role: "assistant", Content: "first result"})
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	s.close()

	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if !json.Valid(raw) || len(bytes.TrimSpace(raw)) == 0 || bytes.TrimSpace(raw)[0] != '[' ||
		bytes.Contains(raw, []byte("\"version\"")) || bytes.Contains(raw, []byte("\"m0\"")) {
		t.Fatalf("session isn't the new unversioned array format: %s", raw)
	}
	loaded, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(loaded.close)
	if loaded.messageCount() != 3 || len(loaded.Transcript) != 3 ||
		loaded.Transcript[1].Content != "objective" || loaded.Transcript[2].Content != "first result" {
		t.Fatalf("round trip changed transcript: %+v", loaded)
	}
	loaded.Transcript = append(loaded.Transcript, Message{Role: "user", Content: "second request"})
	if err := checkpointSession(path, loaded); err != nil {
		t.Fatal(err)
	}
	loaded.close()
	final, err := os.ReadFile(path)
	if err != nil || !json.Valid(final) || bytes.TrimSpace(final)[0] != '[' {
		t.Fatalf("continued session isn't a complete JSON array: %v", err)
	}
	reloaded, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(reloaded.close)
	if reloaded.messageCount() != 4 || reloaded.Transcript[3].Content != "second request" {
		t.Fatalf("second continuation lost messages: %+v", reloaded)
	}
}

func TestFreshSessionCompactionPreservesAbsoluteRange(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.json")
	s := newSession()
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript,
		Message{Role: "user", Content: "old objective"},
		Message{Role: "assistant", Content: "old result"},
		Message{Role: "user", Content: "current objective"},
	)
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	if result := s.editMemory("Keep the objective and old result; continue current objective.", 3); len(result) == 0 || result[:min(len(result), 5)] == "Error" {
		t.Fatalf("compaction failed: %s", result)
	}
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	s.close()
	got, state := regressionReadSavedState(t, nil, path)
	if len(got) != 4 || state.Count != 4 || state.Cursor != 3 ||
		got[1].Content != "old objective" || got[3].Content != "current objective" {
		t.Fatalf("compaction damaged the saved transcript: %#v; %+v", got, state)
	}
}

func TestInterruptedCompactionKeepsPriorCursorAndSummary(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.json")
	s := newSession()
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "objective"})
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	s.Transcript = append(s.Transcript, Message{Role: "assistant", Content: "result before compaction"})
	update := sessionUpdate{
		Messages: []sessionMessage{{Index: 2, Message: s.Transcript[2]}},
		State:    &sessionState{Base: 0, Count: 3, Cursor: 3, Memory: "objective and result summarized"},
	}
	nextOffset, err := writeSessionUpdate(s.owner.file, s.diskOffset, update)
	if err != nil {
		t.Fatal(err)
	}
	if nextOffset <= s.diskOffset {
		t.Fatalf("write did not advance the committed state: old=%d new=%d", s.diskOffset, nextOffset)
	}
	// The simulated process has completed its write; release Windows' exclusive
	// archive handle before mutating the file to model the crash.
	s.close()
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	finalState := []byte(`{"state":{"base":0,"count":3,"cursor":3,"memory":"objective and result summarized"}}`)
	finalAt := bytes.LastIndex(raw, finalState)
	if finalAt < 4 {
		t.Fatalf("fixture lacks the final compacted state: %s", raw)
	}
	// Simulate a crash after the appended message group was committed but
	// before the new compaction cursor/summary was committed.
	torn := raw[:finalAt-4]
	if err := os.WriteFile(path, torn, 0o600); err != nil {
		t.Fatal(err)
	}
	restarted, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(restarted.close)
	if restarted.Cursor != 1 || restarted.Memory != "" || restarted.messageCount() != 3 ||
		len(restarted.Transcript) != 3 || restarted.Transcript[2].Content != "result before compaction" {
		t.Fatalf("interrupted compaction hid uncommitted history: cursor=%d memory=%q count=%d transcript=%+v",
			restarted.Cursor, restarted.Memory, restarted.messageCount(), restarted.Transcript)
	}
	if err := checkpointSession(path, restarted); err != nil {
		t.Fatal(err)
	}
	restarted.close()
	reloaded, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(reloaded.close)
	if reloaded.Cursor != 1 || reloaded.Memory != "" || reloaded.Transcript[2].Content != "result before compaction" {
		t.Fatalf("recovery after an interrupted compaction was not stable: %+v", reloaded)
	}
}

func TestPersistedCountAtIntegerBoundaryRejectsAppend(t *testing.T) {
	path := filepath.Join(t.TempDir(), "boundary.json")
	highest := sessionIntMaxValue()
	base := highest - 2
	system := Message{Role: "system", Content: "rules"}
	user := Message{Role: "user", Content: "last representable request"}
	firstState := sessionState{Base: base, Count: highest - 1, Cursor: highest - 1, Memory: "facts"}
	state := sessionState{Base: base, Count: highest, Cursor: highest, Memory: "facts"}
	events := []sessionEvent{
		{Message: &system},
		{State: &firstState},
		{Message: &user},
		{State: &state},
	}
	raw, err := json.Marshal(events)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, raw, 0o600); err != nil {
		t.Fatal(err)
	}
	file, err := os.OpenFile(path, os.O_RDWR, 0o600)
	if err != nil {
		t.Fatal(err)
	}
	defer file.Close()
	before, err := readSessionLog(file, nil)
	if err != nil || before.Count != highest || before.Cursor != highest {
		t.Fatalf("boundary fixture was not accepted: %+v; %v", before, err)
	}
	update := sessionUpdate{
		Messages: []sessionMessage{{Index: highest, Message: Message{Role: "assistant", Content: "must not wrap"}}},
		State:    &sessionState{Base: base, Count: highest, Cursor: highest, Memory: "facts"},
		Prior:    &before,
	}
	if _, err := writeSessionUpdate(file, before.Offset, update); err == nil {
		t.Fatal("append beyond the largest representable index was accepted")
	}
	after, err := readSessionLog(file, nil)
	if err != nil || after.Count != highest || after.Cursor != highest || after.Offset != before.Offset {
		t.Fatalf("rejected append changed saved state: before=%+v after=%+v err=%v", before, after, err)
	}
	final, err := os.ReadFile(path)
	if err != nil || !json.Valid(final) || !bytes.Equal(final, raw) {
		t.Fatalf("rejected append modified the JSON file: %v", err)
	}
}

func TestSavedMemoryEditCommitsItsToolResultBeforeCompaction(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.json")
	s := newSession()
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "objective"})
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	call := ToolCall{
		ID: "memory-call", Type: "function",
		Function: FunctionCall{Name: "memory_edit", Arguments: `{"memory":"objective and tool result recorded","cursor":0}`},
	}
	imageCall := ToolCall{
		ID: "image-call", Type: "function",
		Function: FunctionCall{Name: "image_read", Arguments: `{"path":"image.png"}`},
	}
	assistant := Message{Role: "assistant", ToolCalls: []ToolCall{call, imageCall}}
	tool := Message{Role: "tool", ToolCallID: call.ID, Name: "memory_edit", Content: wrapResult(1, 2, "Memory edit pending until this tool round's results are recorded.")}
	imageResult := Message{Role: "tool", ToolCallID: imageCall.ID, Name: "image_read", Content: wrapResult(1, 2, "Image attached.")}
	extraImage := Message{Role: "user", Content: []ContentBlock{{Type: "text", Text: "Image file attached."}, {Type: "image_url", ImageURL: &ImageURL{URL: "data:image/png;base64,AA=="}}}}
	if err := appendSessionMessages(s, assistant, tool, imageResult, extraImage); err != nil {
		t.Fatal(err)
	}
	if result := s.stageMemoryEdit(call.ID, "objective and tool result recorded", 0); strings.HasPrefix(result, "Error") {
		t.Fatal(result)
	}
	if _, err := s.applyPendingMemoryEdits(); err != nil {
		t.Fatal(err)
	}
	if s.Cursor != 2 || s.Memory != "objective and tool result recorded" || len(s.Transcript) != 5 {
		t.Fatalf("memory edit didn't preserve the active tool round: cursor=%d memory=%q transcript=%+v", s.Cursor, s.Memory, s.Transcript)
	}
	history, err := s.readHistory(context.Background(), 2, 6)
	if err != nil {
		t.Fatal(err)
	}
	if len(history.Messages) != 4 || history.Messages[0].Message.Role != "assistant" ||
		history.Messages[1].Message.Role != "tool" || history.Messages[2].Message.Role != "tool" ||
		history.Messages[3].Message.Role != "user" {
		t.Fatalf("compaction lost the completed tool group: %+v", history)
	}
	var wrapped ToolResult
	raw, ok := history.Messages[1].Message.Content.(string)
	if !ok || json.Unmarshal([]byte(raw), &wrapped) != nil {
		t.Fatalf("saved tool result isn't structured JSON: %#v", history.Messages[1].Message.Content)
	}
	resultText, ok := wrapped.Result.(string)
	if !ok || !strings.Contains(resultText, "Cursor 1 -> 2") || !strings.Contains(resultText, "context_bytes=") {
		t.Fatalf("saved result doesn't match the committed memory edit: %#v", wrapped.Result)
	}
	restarted, err := loadReservedSession(path, s.owner)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(restarted.close)
	if restarted.Cursor != 2 || restarted.Memory != s.Memory || restarted.messageCount() != 6 {
		t.Fatalf("restart didn't preserve the atomic memory edit: %+v", restarted)
	}
}

func TestMultipleMemoryEditsInOneRoundDoNotReverseCursor(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.json")
	s := newSession()
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "objective"})
	if err := checkpointSession(path, s); err != nil {
		t.Fatal(err)
	}
	first := ToolCall{ID: "mem-1", Type: "function", Function: FunctionCall{Name: "memory_edit", Arguments: `{"memory":"first summary","cursor":2}`}}
	second := ToolCall{ID: "mem-2", Type: "function", Function: FunctionCall{Name: "memory_edit", Arguments: `{"memory":"older boundary","cursor":1}`}}
	s.Transcript = append(s.Transcript, Message{Role: "assistant", ToolCalls: []ToolCall{first, second}})
	s.Transcript = append(s.Transcript,
		Message{Role: "tool", ToolCallID: first.ID, Name: "memory_edit", Content: wrapResult(1, 2, "Memory edit pending.")},
		Message{Role: "tool", ToolCallID: second.ID, Name: "memory_edit", Content: wrapResult(1, 2, "Memory edit pending.")},
	)
	if result := s.stageMemoryEdit(first.ID, "first summary", 2); strings.HasPrefix(result, "Error") {
		t.Fatal(result)
	}
	if result := s.stageMemoryEdit(second.ID, "older boundary", 1); strings.HasPrefix(result, "Error") {
		t.Fatal(result)
	}
	if _, err := s.applyPendingMemoryEdits(); err != nil {
		t.Fatal(err)
	}
	if s.Cursor != 2 || s.Memory != "first summary" || s.messageCount() != 5 {
		t.Fatalf("cursor reversed or summary changed unexpectedly: cursor=%d memory=%q count=%d", s.Cursor, s.Memory, s.messageCount())
	}
	history, err := s.readHistory(context.Background(), 2, 5)
	if err != nil || len(history.Messages) != 3 {
		t.Fatalf("tool-call group not retained: %+v; %v", history, err)
	}
	var firstResult, secondResult ToolResult
	if raw, ok := history.Messages[1].Message.Content.(string); !ok || json.Unmarshal([]byte(raw), &firstResult) != nil {
		t.Fatal("first memory result is invalid JSON")
	}
	if raw, ok := history.Messages[2].Message.Content.(string); !ok || json.Unmarshal([]byte(raw), &secondResult) != nil {
		t.Fatal("second memory result is invalid JSON")
	}
	if result, ok := firstResult.Result.(string); !ok || !strings.Contains(result, "Cursor 1 -> 2") || !strings.Contains(result, "context_bytes=") {
		t.Fatalf("successful edit result is incorrect: %#v", firstResult.Result)
	}
	if result, ok := secondResult.Result.(string); !ok || !strings.Contains(result, "cannot precede the current cursor") {
		t.Fatalf("reverse cursor request was not rejected in its tool result: %#v", secondResult.Result)
	}
}
