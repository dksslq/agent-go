package main

import (
	"context"
	"errors"
	"io"
	"net/http"
	"strings"
	"sync/atomic"
	"testing"
)

func TestEmptySSEEventsContinueTextAndTools(t *testing.T) {
	withStreamDefaults(t)
	for _, ending := range []string{"\n", "\r\n", "\r"} {
		for _, data := range []string{"data:", "data: ", "data", "data: \t ", "data:\ndata:"} {
			t.Run(strings.ReplaceAll(ending+data, "\n", "LF"), func(t *testing.T) {
				empty := strings.ReplaceAll(data, "\n", ending) + ending + ending
				for _, tools := range []bool{false, true} {
					wire := empty + deltaChunk(t, map[string]interface{}{contentField: "before"}, "") + empty
					var got []StreamEvent
					if tools {
						wire += toolCallChunk(t, 0, "call_empty", "exec", `{"program":`) + empty + toolCallChunk(t, 0, "", "", `"echo"}`) + empty + deltaChunk(t, nil, "tool_calls")
					} else {
						wire += deltaChunk(t, map[string]interface{}{contentField: "after"}, "") + empty + sseData("[DONE]")
					}
					err := consumeChatStream(strings.NewReader(wire), func(e StreamEvent) error { got = append(got, e); return nil })
					if err != nil {
						t.Fatal(err)
					}
					if len(got) != 2 || got[0].Text != "before" {
						t.Fatalf("unexpected events: %+v", got)
					}
					if tools {
						if got[1].Type != EventToolCalls || len(got[1].ToolCalls) != 1 || got[1].ToolCalls[0].Function.Arguments != `{"program":"echo"}` {
							t.Fatalf("lost tool fragments: %+v", got)
						}
					} else if got[1].Text != "after" {
						t.Fatalf("lost text: %+v", got)
					}
				}
			})
		}
	}
}

func TestEmptySSEDoesNotHideErrorsOrFinishEarly(t *testing.T) {
	withStreamDefaults(t)
	for _, tc := range []struct {
		name, wire, want string
		retry            bool
	}{
		{"eof", "data:\n\n", "before completion", true},
		{"unterminated", "data:", "before completion", true},
		{"bad_json", "data:\n\ndata: {invalid\n\n", "invalid stream JSON", false},
		{"api_error", "data:\n\ndata: {\"error\":{\"message\":\"denied\"}}\n\n", "API stream error", false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			err := consumeChatStream(strings.NewReader(tc.wire), func(StreamEvent) error { return nil })
			if err == nil || !strings.Contains(err.Error(), tc.want) || errors.Is(err, errRoundRetry) != tc.retry {
				t.Fatalf("error=%v", err)
			}
		})
	}
	// Empty data lines within one event are retained in multiline JSON assembly.
	wire := "data: {\"choices\":[\n" + "data:\n" + "data: {\"delta\":{\"content\":\"ok\"},\"finish_reason\":\"stop\"}]}\n\n"
	var text string
	if err := consumeChatStream(strings.NewReader(wire), func(e StreamEvent) error { text += e.Text; return nil }); err != nil || text != "ok" {
		t.Fatalf("multiline: %q, %v", text, err)
	}
}

func TestEmptySSEInferenceSucceedsWithoutRetry(t *testing.T) {
	withStreamDefaults(t)
	output := captureAgentStdout(t)
	var requests int32
	withSSEServer(t, func(w http.ResponseWriter, _ *http.Request) {
		atomic.AddInt32(&requests, 1)
		io.WriteString(w, "data:\n\n"+deltaChunk(t, map[string]interface{}{contentField: "ok"}, "")+"data: \n\n"+sseData("[DONE]"))
	})
	s := newSession()
	defer s.close()
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "task"})
	if err := runInferenceLoop(context.Background(), s); err != nil {
		t.Fatal(err)
	}
	if atomic.LoadInt32(&requests) != 1 || output() != "ok\n" || len(s.Transcript) != 3 || s.Transcript[2].Content != "ok" {
		t.Fatalf("requests=%d output=%q transcript=%+v", requests, output(), s.Transcript)
	}
}
