# agent-go 技术参考（简体中文）

> 本文保留完整的命令、工具、会话格式与资源边界说明。返回主页：[English](../README.md) · [简体中文](../README.zh-CN.md)。

## 安装与运行

```bash
go install github.com/dksslq/agent-go@main
```

也可以从 [Release](https://github.com/dksslq/agent-go/releases) 下载对应平台的二进制。Debian / Ubuntu 的包名为 `agentlet`，安装后命令为 `agentlet`；Go 安装后的命令为 `agent-go`。

```bash
# 本地构建
git clone https://github.com/dksslq/agent-go.git
cd agent-go
go build -o agent .

# 设置模型与 API 地址；认证通过环境设置注入 AGENT_API_KEY
export AGENT_MODEL='your-model'
export AGENT_API_BASE='http://localhost:8080/v1'

# 交互使用
./agent

# 执行一项任务后退出
./agent -once -prompt '检查当前项目，运行测试并报告结果'

# stdin 是任务数据；-prompt 是附加指令
./agent -pipe -prompt '分析日志，给出有证据的结论' < error.log > report.md

# 载入已有会话，或新建；每个工具轮次及用户轮次结束后保存
./agent -continue session.json -once -prompt '继续检查剩余问题'
```

模型服务需要支持流式 Chat Completions 和工具调用；图片功能还需要模型支持视觉输入。环境变量 `AGENT_MODEL`、`AGENT_API_BASE`、`AGENT_API_KEY` 提供默认值，同名命令行参数覆盖它们。HTTP 代理使用 Go 的标准 `HTTP_PROXY`、`HTTPS_PROXY`、`NO_PROXY` 规则；HTTPS 保留证书校验。

模型通过 HTTP / SSE 连接；内置工具在本机执行。目前支持文本与图片输入，不包含音频、视频或 MCP 工具服务接入。

## 自主运行的行为

`-once` 要求提供非空 `-prompt`。`-pipe` 读取 stdin 至 EOF，将它与可选的 `-prompt` 用空行连接，原样保留 stdin 的空白与文本，并隐含 `-once`。这两种模式不切换终端状态，也不打印交互提示符。

stdout 输出流式助手正文，包括工具执行前的说明；工具状态与运行错误走 stderr。交互终端保持显示推理内容；非交互运行仅在 `-verbose` 时输出推理内容到 stderr。工具日志默认只展示名称，`-verbose` 才展示工具参数与结果。这些详细日志可能包含任务数据，请按需要开启。

流式正文不会为重试而暂存。如果流在已经输出部分文本后失败，stdout 会尽力插入 `[agent-go: response interrupted; preceding output may be incomplete]` 标记，再继续可能的重试；此前已经写出的字节不会撤回。因而一次任务可能在最终重试成功、退出码为 0 的同时，仍包含先前失败轮次的部分文本。消费 stdout 的程序应检查该标记和退出码；输出目标不可写或运行已取消时，标记可能无法输出。

| 退出码 | 含义 |
|---|---|
| `0` | 成功完成 |
| `1` | 参数、API、输入、输出或会话保存错误 |
| `130` | 被 SIGINT / Ctrl+C 中断 |
| `143` | 收到 SIGTERM 并退出 |

API 认证与请求拒绝、输出或保存失败仍按错误处理并带非零退出码。模型输出缺陷（如工具参数 JSON 不完整、空响应或未完成的工具调用）以及断流会被标记为中止轮次，并将原因反馈给模型重试；若同一失败重复且没有进展，程序停止，避免空转。程序不会重试已执行过的工具或重放输出，也不会掩盖退出码。中止反馈明确标记为运行时通知，其中已输出的模型正文以转义字符串引用，不能作为新的用户指令；用户中断可能发生在工具已产生部分副作用之后。中断时已经输出的正文可能不完整，消费结果时应同时检查退出码。

同一响应中的独立工具并行执行，结果按调用顺序回传；`memory_edit` 在整轮工具结果加入 transcript 后按调用顺序提交摘要与游标。存在依赖的工作应拆成多个工具轮次。多个 Agent 可以由 shell、CI 或服务管理器作为独立进程调度；每个进程使用独立会话文件，避免互相覆盖。

## 工具与输出

| 工具 | 行为 |
|---|---|
| `exec` | 直接启动程序，将 `input` 写入 stdin，分别返回 stdout、stderr 与退出码；非交互式执行，使用管道输入输出。支持工作目录、环境、超时、后台启动与输出文件 |
| `image_read` | 读取本地常规图片文件，附加为视觉输入 |
| `memory_edit` | 用完整 `memory` 替换语义记忆；将已完成历史从后续模型请求中移除，保留在选定档案中的原文仍可由 `history_read` 读取 |
| `history_read` | 按绝对索引读取所选会话档案中的原始消息；只读，不创建文件 |

`exec` 将 `args` 作为独立参数直接传给程序，不隐式展开变量、通配符、管道或重定向；需要 shell 语法时显式启动当前平台的 shell。`input` 写入后关闭 stdin，程序不等待交互输入。前台执行要求字符串 `timeout`，例如 `"250ms"`、`"10s"`、`"1m30s"`；不带单位的十进制数按秒解析，如 `"10"` 和 `"0.5"`。支持 `ns`、`us` / `µs`、`ms`、`s`、`m`、`h`，使用 `time.ParseDuration` 解析；拒绝零、负数、溢出、科学计数法与首尾空白，低于 1 纳秒的值同样拒绝。原数字字段 `timeout_seconds` 已替换为 `timeout`；`detach: true` 不等待退出、不捕获输出，并忽略超时。后台进程的后续管理由调用者负责。

`exec` 的 `result` 是 JSON 对象，例如：

```json
{"stdout":"","stderr":"test failed\n","exit_code":1}
```

`stdout`、`stderr` 始终为字符串。正常退出时 `exit_code` 是程序退出码；信号终止通常为 `-1`，未启动或后台启动时为 `null`。正常非零退出不会重复生成错误说明；超时、取消、信号终止、启动或输出 I/O 失败才附带 `error`，已经捕获的输出仍保留。后台启动成功还返回 `pid`。

输出有两种选择，由模型按任务决定：

- 未设置 `output_file` 时，默认完整回传两个流。正数 `max_output_chars` 分别限制每个流的 Unicode 字符预览；省略或 `0` 表示完整输出。
- 设置 `output_file` 时，两个流的完整原始字节写入一个**新文件**，回传 `output_file`、`output_bytes` 以及可选预览。路径相对于 `cwd`，已有文件会导致工具报错。此时省略或 `0` 的 `max_output_chars` 表示不附带预览。输出文件不能与 `detach` 同用；合并文件不保证两个流之间的先后顺序。

发生截断时才附带 `stdout_truncated: true` / `stderr_truncated: true`，程序输出本身不插入提示文字。预览达到上限后仍继续读取两个流、等待命令完成，不会因为预览截断而杀死程序。需要保留完整日志时使用输出文件，再通过 `exec` 检索相关片段：

```json
{
  "program": "go",
  "args": ["test", "./..."],
  "input": "",
  "timeout": "2m",
  "output_file": "test.log",
  "max_output_chars": 4000
}
```

输出文件保留在磁盘上，需要自行归档或删除。字符数与 JSON 字节数均不是 token 数；程序不猜测模型的 tokenizer 或上下文窗口，也不暗中裁掉工具输出。

## 记忆与会话

上下文由系统提示词、语义记忆和未压缩的历史组成。`memory_edit` 用完整摘要替换旧摘要，并从活动 transcript 中移除已压缩的消息；应保留当前目标、约束、关键事实、结果、路径与下一步。

静态系统提示词仅保留一句话：`Complete authorized tasks accurately, preserve relevant state, verify outcomes, and respect stop requests.` 工具说明承载具体用法；独立的运行状态消息提供工作目录、保存模式和指标含义，不显式提供 OS/架构，也不枚举环境变量或密钥。`memory_edit` 应在里程碑和大量输出之后整理记忆；程序不猜测窗口大小，也不按固定阈值触发压缩。

默认压缩所有已完成的历史，**包括同一任务中先前完成的步骤**。尚未收齐结果的工具调用组保留，调用与结果不会被游标拆开。可选 `cursor` 使用完整 transcript 的绝对索引，游标只能向前移动。整理后若剩余历史以助手消息开头，API 请求加入明确标记的用户续接锚点，保留工具调用配对；锚点不写入原始历史。

Agent 不创建临时文件或隐含存档。会话只写入用户明确指定的文件；`exec` 执行的程序仍可按其自身行为写文件。

`memory_edit` 会从驻留 transcript 和后续模型请求中移除已压缩的消息；选定档案仍保留的原文可通过 `history_read` 按需读取。未保存、也不在所选档案中的原文不可恢复。未调用压缩时，活跃历史仍会随对话增长。

保存、加载与持续保存分别控制：

| 操作 | 行为 |
|---|---|
| `/save <file>` | 将当前状态另存至新文件，随即关闭；不改变已有持续保存绑定 |
| `/load <file>` | 只读加载后关闭文件，停止原来的持续保存；`/reload` 是兼容别名 |
| `/continue <file>` | 载入已有会话或新建，持续保存至该文件 |
| `-save <file>` | 退出时另存当前状态；可搭配 `-load` 或 `-continue`，冲突在写入时拒绝 |
| `-load <file>` | 只读加载，不更新源文件；不能与 `-continue` 同用 |
| `-continue <file>` | 启动时载入或新建，持续保存至该文件 |

这些交互命令由用户在终端输入，不属于模型可调用的工具。

`/load` 与 `/continue` 切换当前会话；`/continue` 的目标不存在时创建空会话。已有持续保存不因单次另存而停止；此时回溯工具仍读取持续保存的日志。

持续保存模式会先记录完整工具轮次，再提交新的摘要与游标，最后压缩活动 transcript。单次快照不会记录后续消息；此前已经释放且未保存的原文也无法补回，晚保存只能保留现有摘要与剩余历史。

加载或保存的会话可供 `history_read` 显式回溯。必填参数 `start`、`end` 是绝对索引，范围为 `[start, end)`；`[0, 0)` 只查询边界。结果的 `next` 是档案上界，`[1, base]` 表示保存前已经丢失的原文。工具按需读取所选范围，返回内容进入当前上下文；总结所需信息后用 `memory_edit` 压缩。档案中不存在的原文无法恢复。

每个工具轮次的最后一个结果附带 `last_request_bytes`：它是刚完成推理所发送的完整请求 JSON 字节数，包含消息、工具定义与附加字段，不是 token 数或剩余窗口容量。有档案时还附带 `history_next`，提供可读索引上界。动态观测只追加到新结果中，避免每轮改写系统与记忆前缀。记忆编辑回传游标、下一索引与当前上下文字节数。

会话使用无版本标志的 JSON 数组。每项是 `{"message": ...}` 或 `{"state": {"base", "count", "cursor", "memory"}}`；消息顺序由数组决定，不为每条消息保存索引键。每批消息后写入 state 作为提交点；崩溃留下的未提交尾部会被忽略，下一次保存从最后提交点恢复。读取和另存以流式方式处理历史；普通追加使用已提交的内存状态，不会每轮重扫整个档案。加载只把系统消息和游标之后的活跃尾部放入 RAM；`history_read` 按显式范围回读原文，不自动把整个档案放进模型上下文。

只接受当前无版本标志的数组格式，并检查消息顺序、工具调用配对与状态边界；格式错误时拒绝加载，不改写原文件。

模型实际返回的 `reasoning_content` 随 assistant 消息保存并回传。如果当前数组档案缺少服务要求的推理字段，程序不补造推理、不丢弃历史、不切换模式或自动重试；会明确报告 API 错误，保留原档案。

另存始终要求新文件，拒绝覆盖已有文件，包括刚加载的源文件；更新已有会话应明确使用 `-continue` 或 `/continue`。冲突在写入时刻立即失败，不等待或重试；不做启动期路径预检，符号链接、大小写等外部别名形态由操作系统在打开或写入时报告。

Windows 仅在持续保存期间独占目标文件，拒绝其他读写及删除打开，包括 `exec` 子进程的读取；`history_read` 使用已有句柄读取，无需解除独占。另存和只读加载在操作完成后关闭文件，`exec` 随后可正常访问。保存不依赖文件替换。Unix 不加进程互斥，各进程应使用独立会话文件。

持续保存在每个工具轮次和用户轮次结束后提交检查点，保存失败会停止当前推理并报告错误。检查点记录会话，不能把外部程序的副作用与保存操作组成事务：异常退出后应先核实已有文件、进程或服务状态，再决定是否重试。

没有固定的工具轮数、图片大小或默认输出大小上限。完整内联输出和未整理的活跃上下文仍会消耗内存与模型额度；显式会话和输出文件会占用磁盘。持续任务应主动整理记忆，按需保存会话和文件输出，CPU、内存、磁盘和进程权限由运行环境配置。

## 参数与交互

| 参数 | 默认 / 用途 |
|---|---|
| `-model` | `AGENT_MODEL`；必须指定模型 |
| `-api-base` | `AGENT_API_BASE`，否则 `http://localhost:8080/v1` |
| `-api-key` | `AGENT_API_KEY`，否则为空 |
| `-prompt` / `-once` / `-pipe` | 启动提示词、单次执行、读取 stdin |
| `-load` / `-save` / `-continue` | 只读加载、退出时另存、载入或新建并持续保存 |
| `-verbose` | 默认关闭；显示推理、工具参数与结果 |
| `-stream-idle-timeout` | `5m`；等待网络数据的空闲超时，`0` 关闭；`-tool-call-idle-timeout` 为兼容别名 |
| `-http-idle-timeout` | `5m`；空闲 HTTP 连接保留时间 |
| `-http-max-idle-conns` | `100`；保留的空闲 HTTP 连接数 |
| `-reasoning-field` / `-content-field` | delta 字段名，默认 `reasoning_content` / `content` |
| `-tool-calls-field` / `-finish-reason-field` | 默认 `tool_calls` / `finish_reason` |
| `-extra` | 可重复的 Base64 JSON 对象；附加厂商参数，不能覆盖 `model`、`messages`、`tools`、`stream` |

`-stream-idle-timeout` 覆盖请求连接、响应头以及后续网络读取等待，不限制一个持续产生数据的任务总时长。Go 标准传输层的连接与 TLS 握手超时仍然适用。

终端按 Enter 发送。支持 bracketed paste 的终端会保留粘贴中的换行、缩进和特殊字符，粘贴结束后仍需按 Enter；Alt+Enter（以及终端支持时的 Shift+Enter）插入换行。旧终端先输入 `/paste`，再输入或粘贴多行，按 Ctrl+D 发送。多行文本不会被解释为交互命令。键盘 Ctrl+C 仍按中断处理。

交互命令：`/paste`、`/help`、`/image <path>`、`/image-url <url>`、`/pending`、`/clear`、`/memory`、`/save <file>`、`/load <file>`、`/continue <file>`，以及 `exit` / `quit`。`/reload` 是 `/load` 的兼容别名。`/memory` 显示记忆、游标与上下文 JSON 字节数。Ctrl+C 中断当前推理轮，空闲时退出；Ctrl+D 结束输入。SIGTERM 结束整个进程。

Linux / macOS 的前台命令在独立进程组中运行，取消时终止该进程组。Windows 的取消只保证终止直接子进程；需要管理完整进程树时由外部运行环境负责。任何平台的进程控制都不能保证立即结束不可中断的内核操作。

`exec` 继承 Agent 的操作系统权限。生产部署应使用符合任务需要的用户、目录权限和隔离环境。工具输出与记忆作为数据处理，用户授权的文档可用于完成任务；系统提示词不能代替操作系统的权限控制。

## 开发与验证

```bash
bash .github/test.sh
```

CI 在 Linux 的 Go 1.21 与 stable、macOS stable、Windows stable 上运行检查与竞态测试，并交叉编译 Linux / macOS / Windows × amd64 / arm64。测试使用标准库 `testing`、`httptest` 和真实子进程；Linux 还使用 PTY 验证行输入。发布工作流由 `v*` 标签触发，构建平台二进制与 Debian 包。

代码按职责拆分：`cli.go` 处理入口与信号，`agent.go` 处理推理与工具，`openai.go` 处理 API / SSE，`memory.go` 处理记忆与会话操作，`session_log.go` 处理会话文档读写，`history.go` 处理历史回溯，`exec_output.go` 处理输出捕获，`output.go` 处理可取消的标准输出，`exec_*.go` / `term_*.go` / `session_*.go` 提供平台适配。它们构建为同一个可执行文件。

程序设计见 [设计纲要](program-design.zh-CN.md)，测试布局与验证命令见 [测试说明](testing.md)，当前改动见 [CHANGES.md](../CHANGES.md)。

## 许可与署名

[MIT](../LICENSE)。开发者：DeepSeek、GLM (Z.ai)、Codex (OpenAI，审计、重构与测试)。
