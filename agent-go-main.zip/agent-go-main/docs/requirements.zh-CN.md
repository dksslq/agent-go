# 项目要求与运行约束

本文把终端用户、开发测试和发布所需条件集中列出。命令、工具参数与会话字段的完整说明仍以[技术参考](reference.zh-CN.md)为准。

## 运行要求

### 操作系统与构建

- 支持 Linux、macOS 和 Windows；发布工作流为每个平台构建 `amd64` 与 `arm64` 共六种二进制。
- 从源码构建需要 Go 1.21 或更新版本。项目使用 Go 标准库，不要求额外的 Go 模块依赖。
- 发布二进制使用 `CGO_ENABLED=0`，不要求目标机器安装 Go 或 C 编译器。
- Debian/Ubuntu 的 `.deb` 包由 Linux 发布作业构建，目标为 amd64；包名为 `agentlet`，安装后的命令也叫 `agentlet`。独立二进制的命令名为 `agent-go`（Windows 为 `agent-go.exe`）。

### 模型服务

- 必须指定模型名称（命令行参数或 `AGENT_MODEL`）。
- 服务端需兼容 OpenAI Chat Completions API，并支持流式响应（SSE）和工具调用。
- API Base 默认值为 `http://localhost:8080/v1`；可通过 `-api-base` 或 `AGENT_API_BASE` 覆盖。
- `AGENT_API_KEY` / `-api-key` 用于需要认证的服务；本地无认证服务可以留空。
- 图片输入要求模型和服务端都支持视觉输入。运行时不支持音频、视频或 MCP 工具服务器接入。

程序运行不要求特定云服务；本地或远程服务均可，只要符合上述协议。网络可达性、认证与服务端配额由实际部署环境决定。

## 开发与验证要求

### 本地工具链

- Go 1.21+。
- Bash，用于仓库中的测试和打包脚本；Windows 开发者可在 Git Bash、MSYS2 或兼容环境运行这些脚本。
- 完整测试脚本设置 `CGO_ENABLED=1` 并启用 race detector，因此需要当前平台支持的 C 编译工具链。只有交叉编译发布二进制时使用 `CGO_ENABLED=0`。
- 单元和回归测试使用本地模拟 HTTP 服务与子进程，不需要真实模型密钥。

### 标准验证

在仓库根目录运行：

```bash
bash .github/test.sh
```

脚本依次执行：

1. `gofmt -l .` 格式检查；
2. `go vet ./...` 静态分析；
3. `CGO_ENABLED=1 go test -count=1 -race -shuffle=on -gcflags=all=-d=checkptr=2 -timeout=6m ./...`，启用竞态检测、随机测试顺序和指针检查。

覆盖率示例：

```bash
bash .github/test.sh -covermode=atomic -coverprofile=coverage.txt
go tool cover -func=coverage.txt
```

交叉编译只能证明相应目标可以构建，不能替代在目标操作系统上的真实运行测试。CI 的完整矩阵还包括 Go 1.21 与 stable、Linux/macOS/Windows、六种 GOOS/GOARCH 组合，以及 Debian 包的安装与二进制检查。

### Debian 包构建

复现 CI 的打包作业需要 Debian/Ubuntu 环境及 `build-essential`、`golang-any`、`debhelper`、`dh-golang` 和 dpkg 工具。执行：

```bash
bash .github/build-deb.sh
dpkg-deb --info dist/agentlet_*.deb
```

发布流程会为二进制与 Debian 包生成 `SHA256SUMS`。

## 数据与兼容性要求

- 新会话档案采用**无版本标志的 JSON 数组**；消息顺序由数组表达，没有逐消息索引键。
- 不做旧会话格式迁移。升级前应备份需要保留的会话；不能假定旧格式可由当前版本加载。
- 只有明确指定会话文件时才启用会话持久化；持续保存使用 `-continue` 或相应交互命令。普通运行不会隐式创建档案。
- 每个完整消息/工具调用组后有提交状态。崩溃或中断留下的未提交尾部不应当作有效历史。
- 游标和历史索引是绝对索引，游标只能向前移动；不可表示的计数或偏移必须报错，不得回绕后继续保存。

## 权限与运行风险

- **agent-go 不是沙箱。** `exec` 直接启动本地程序，子进程具有 Agent 进程所拥有的操作系统权限，并可能继承其环境变量。应使用最小权限账户、限制工作目录，并避免把无关凭据放进进程环境。
- 工具调用、超时或取消与外部副作用不是一个原子事务。进程可能在外部程序完成部分操作后、保存检查点前退出；超时/取消不代表副作用已回滚。重试前先检查文件、进程和外部服务的真实状态。
- 不设置固定的会话档案消息数、档案字节数、历史读取范围或摘要长度上限。显式读取大量历史、长时间不压缩，或让完整命令输出直接进入上下文，仍可能消耗大量内存与模型额度。需要控制资源时，应由调用者通过任务策略、`max_output_chars`、输出文件、主动摘要和操作系统资源约束进行管理。
- `output_file` 会把完整 stdout/stderr 写入一个新文件；已有目标文件会报错。保存的会话、命令输出和详细日志可能包含敏感数据，应按敏感数据保护。

## 发布约定

更新 `docs/release.md` 并推送到 main 会触发正式发布，也可手动运行 `.github/workflows/release.yml`。发布先完成 Linux/macOS/Windows 原生测试（含 Go 1.21 最低版本检查），再交叉构建六种二进制、构建 Debian amd64 包、检查产物并生成 SHA-256 校验文件。最后以源码提交标识创建 GitHub 标签和 Release，标题不带版本号；会话格式始终不携带版本字段。Debian 包仅保留包管理器要求的日期版本字段。
