package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

// Verifies the user-reported failure: a model tool call with malformed JSON
// arguments no longer terminates the process; the round is retried with the
// abort marker as feedback and the model self-corrects.
func TestMalformedToolCallRetriesInsteadOfStopping(t *testing.T) {
	withStreamDefaults(t)
	s := newSession()
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "fix the server"})
	var requests int32
	var sawMarker int32
	withSSEServer(t, func(w http.ResponseWriter, r *http.Request) {
		n := atomic.AddInt32(&requests, 1)
		var body strings.Builder
		buf := make([]byte, 4096)
		for {
			k, err := r.Body.Read(buf)
			if k > 0 {
				body.Write(buf[:k])
			}
			if err != nil {
				break
			}
		}
		if strings.Contains(body.String(), "[Turn aborted: tool call") {
			atomic.StoreInt32(&sawMarker, 1)
			// DeepSeek rejects a thinking-mode request whose tail is an
			// assistant message without reasoning_content; the abort
			// feedback must therefore ride on a user message.
			var req struct {
				Messages []Message `json:"messages"`
			}
			if err := json.Unmarshal([]byte(body.String()), &req); err != nil {
				t.Errorf("bad retry request: %v", err)
			} else if n := len(req.Messages); n > 0 && req.Messages[n-1].Role == "assistant" {
				t.Errorf("retry request tail is an assistant message: %+v", req.Messages[n-1])
			}
		}
		if n == 1 {
			// Exactly the reported shape: tool call whose streamed arguments
			// are truncated, with finish_reason=tool_calls.
			fmt.Fprint(w, toolCallChunk(t, 0, "call_00_5PJnTJOqBE7yLhNHIJdz3642", "exec", `{"program":"bash","args":["-c","echo hi`)+"\n\n")
			fmt.Fprint(w, `data: {"choices":[{"delta":{},"finish_reason":"tool_calls"}]}`+"\n\n")
			fmt.Fprint(w, "data: [DONE]\n\n")
			return
		}
		fmt.Fprint(w, deltaChunk(t, map[string]interface{}{reasoningField: "thought", contentField: "recovered"}, ""))
		fmt.Fprint(w, deltaChunk(t, map[string]interface{}{reasoningField: " then ", contentField: " and completed"}, "stop"))
		fmt.Fprint(w, "data: [DONE]\n\n")
		fmt.Fprint(w, "data: [DONE]\n\n")
	})
	if err := runInferenceLoop(context.Background(), s); err != nil {
		t.Fatalf("program stopped on malformed tool call: %v", err)
	}
	if atomic.LoadInt32(&requests) != 2 {
		t.Fatalf("expected one self-correction retry, got %d requests", requests)
	}
	if atomic.LoadInt32(&sawMarker) != 1 {
		t.Fatalf("retry request did not include the abort marker feedback")
	}
	var feedback, answers, reasoning strings.Builder
	for _, m := range s.Transcript {
		if c, ok := m.Content.(string); ok {
			switch m.Role {
			case "user":
				feedback.WriteString(c)
				feedback.WriteString("\n")
			case "assistant":
				answers.WriteString(c)
				answers.WriteString("\n")
				reasoning.WriteString(m.ReasoningContent)
			}
		}
	}
	if !strings.Contains(feedback.String(), "prior stream failure recovered") {
		t.Fatalf("transcript missing the compact runtime recovery notice: %q", feedback.String())
	}
	if strings.Contains(feedback.String(), "[Turn aborted:") {
		t.Fatalf("recovered transcript retained the verbose failed-round marker: %q", feedback.String())
	}
	if !strings.Contains(answers.String(), "recovered and completed") {
		t.Fatalf("transcript missing final answer: %q", answers.String())
	}
	if reasoning.String() != "thought then " {
		t.Fatalf("assistant messages must carry back the streamed reasoning, got %q", reasoning.String())
	}
}

func captureAgentStdout(t *testing.T) func() string {
	t.Helper()
	file, err := os.CreateTemp(t.TempDir(), "agent-stdout-*")
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	oldWriter, oldOutputErr := stdoutWriter, outputErr
	stdoutWriter = newOutputWriter(ctx, file)
	outputErr = nil
	t.Cleanup(func() {
		stdoutWriter = oldWriter
		outputErr = oldOutputErr
		cancel()
		_ = file.Close()
	})
	return func() string {
		t.Helper()
		if err := file.Sync(); err != nil {
			t.Fatal(err)
		}
		content, err := os.ReadFile(file.Name())
		if err != nil {
			t.Fatal(err)
		}
		return string(content)
	}
}

func TestResponseHeaderIdleTimeoutRetries(t *testing.T) {
	withStreamDefaults(t)
	streamIdleTimeout = 50 * time.Millisecond
	capture := captureAgentStdout(t)
	var requests atomic.Int32
	withSSEServer(t, func(w http.ResponseWriter, r *http.Request) {
		// Drain the request body before waiting, matching net/http's normal
		// request lifecycle and avoiding a test-server keepalive deadlock.
		_, _ = io.Copy(io.Discard, r.Body)
		if requests.Add(1) == 1 {
			// Simulate a server that receives the request but never sends headers.
			<-r.Context().Done()
			return
		}
		fmt.Fprint(w, deltaChunk(t, map[string]interface{}{contentField: "recovered"}, "stop"))
		fmt.Fprint(w, "data: [DONE]\n\n")
	})

	s := newSession()
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "retry after header timeout"})
	if err := runInferenceLoop(context.Background(), s); err != nil {
		t.Fatalf("header-timeout retry failed: %v", err)
	}
	if requests.Load() != 2 {
		t.Fatalf("requests=%d, want 2 (one timeout and one successful retry)", requests.Load())
	}
	if got := capture(); !strings.Contains(got, "recovered") {
		t.Fatalf("successful retry response missing from stdout: %q", got)
	}
	if last := s.Transcript[len(s.Transcript)-1]; last.Role != "assistant" || last.Content != "recovered" {
		t.Fatalf("successful retry not recorded: %+v", last)
	}
}

func TestPartialStreamFailureEmitsMarkerBeforeRetryOutput(t *testing.T) {
	withStreamDefaults(t)
	capture := captureAgentStdout(t)
	var requests atomic.Int32
	withSSEServer(t, func(w http.ResponseWriter, _ *http.Request) {
		if requests.Add(1) == 1 {
			fmt.Fprint(w, deltaChunk(t, map[string]interface{}{contentField: "partial"}, ""))
			w.(http.Flusher).Flush()
			// Returning without finish_reason/[DONE] simulates a severed stream.
			return
		}
		fmt.Fprint(w, deltaChunk(t, map[string]interface{}{contentField: "recovered"}, "stop"))
		fmt.Fprint(w, "data: [DONE]\n\n")
	})

	s := newSession()
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "recover interrupted stream"})
	if err := runInferenceLoop(context.Background(), s); err != nil {
		t.Fatalf("stream retry failed: %v", err)
	}
	if requests.Load() != 2 {
		t.Fatalf("requests=%d, want 2", requests.Load())
	}
	got := capture()
	marker := "[agent-go: response interrupted; preceding output may be incomplete]"
	partialAt, markerAt, recoveredAt := strings.Index(got, "partial"), strings.Index(got, marker), strings.LastIndex(got, "recovered")
	if partialAt < 0 || markerAt < partialAt || recoveredAt < markerAt {
		t.Fatalf("expected partial output, abort marker, then retry output; got %q", got)
	}
}

type contextWaitingBody struct {
	ctx context.Context
}

func (b contextWaitingBody) Read([]byte) (int, error) {
	<-b.ctx.Done()
	return 0, b.ctx.Err()
}

func (contextWaitingBody) Close() error { return nil }

func TestHTTPRejectionIsNotRetriedWhenErrorBodyTimesOut(t *testing.T) {
	withStreamDefaults(t)
	streamIdleTimeout = 50 * time.Millisecond
	var requests atomic.Int32
	httpClient = &http.Client{Transport: streamRoundTripper(func(req *http.Request) (*http.Response, error) {
		if requests.Add(1) == 1 {
			return &http.Response{
				StatusCode: http.StatusTooManyRequests,
				Header:     make(http.Header),
				Body:       contextWaitingBody{ctx: req.Context()},
			}, nil
		}
		// If an HTTP rejection is accidentally classified as retryable, this
		// second response makes the test fail by letting the round complete.
		return &http.Response{
			StatusCode: http.StatusOK,
			Header:     make(http.Header),
			Body: io.NopCloser(strings.NewReader(
				deltaChunk(t, map[string]interface{}{contentField: "must not run"}, "stop") + "data: [DONE]\n\n")),
		}, nil
	})}

	s := newSession()
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "HTTP errors should stay fatal"})
	err := runInferenceLoop(context.Background(), s)
	if err == nil || !strings.Contains(err.Error(), "API error 429") {
		t.Fatalf("expected the original HTTP rejection, got %v", err)
	}
	if requests.Load() != 1 {
		t.Fatalf("HTTP rejection was retried %d times; want exactly one request", requests.Load())
	}
}
