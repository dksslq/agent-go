# agent-go

**English** · [简体中文](README.zh-CN.md)

## Give AI a real system to operate.

agent-go is a small, stateful execution runtime for autonomous AI work. It connects an OpenAI-compatible streaming Chat Completions model to real local tools, so an agent can plan, run programs, observe results, adjust its next action, and continue work across sessions.

The goal is not another chat interface. It is a compact bridge between an AI agent and the operating system where real work happens.

[![CI](https://github.com/dksslq/agent-go/actions/workflows/ci.yml/badge.svg)](https://github.com/dksslq/agent-go/actions/workflows/ci.yml) · [Releases](https://github.com/dksslq/agent-go/releases) · [MIT](LICENSE)

- **Act:** run local programs and inspect stdout, stderr, and exit codes.
- **Observe:** receive tool results and use them to decide what to do next.
- **Remember:** maintain semantic memory, compact completed history, and read archived messages.
- **Resume:** explicitly save sessions and continue long-running investigations later.
- **Deploy:** one Go binary per platform, no third-party Go dependencies, no cgo.

Supports Linux, macOS, and Windows on amd64 and arm64. Building requires Go 1.21+. Session files use a fresh, unversioned JSON array format; older session formats are not migrated.

Release binaries and the Debian package use `CGO_ENABLED=0` with `-ldflags "-s -w -buildid=" -trimpath`.

## Quick start

Install with Go:

~~~bash
go install github.com/dksslq/agent-go@main
~~~

Configure an OpenAI-compatible endpoint. The API key is optional for local services that do not require authentication.

~~~bash
export AGENT_API_BASE="http://localhost:8080/v1"
export AGENT_MODEL="your-model"
export AGENT_API_KEY="your-key" # if required

agent-go
~~~

The default API base is http://localhost:8080/v1. The service must support streaming Chat Completions and tool calling. Image analysis additionally requires a vision-capable model and endpoint.

Run one autonomous task and exit:

~~~bash
agent-go -once -prompt "Inspect this repository, run go test ./..., explain any failures with evidence, and do not modify files."
~~~

Feed data through stdin. The input is combined with the prompt, and -pipe implies one-shot mode:

~~~bash
cat build.log | agent-go -pipe -prompt "Group build failures by root cause, cite useful evidence, and suggest next checks." > build-report.md
~~~

Streaming output is written as it arrives; failed output is not buffered or withdrawn. If a streamed response fails after emitting text, agent-go writes an explicit `[agent-go: response interrupted; preceding output may be incomplete]` marker before continuing a retry. A later successful retry can still exit with status 0, so consumers should inspect stdout for this marker as well as checking the exit status. The marker is best-effort when the output destination is still writable; cancellation or a broken destination can prevent it.

On Windows, configure environment variables in PowerShell with $env:AGENT_API_BASE, $env:AGENT_MODEL, and (if required) $env:AGENT_API_KEY; use agent-go.exe as the executable name. Prebuilt binaries are attached to published [Releases](https://github.com/dksslq/agent-go/releases). If no release is listed yet, use `go install` above or build from source. The Debian/Ubuntu package installs the command `agentlet`.

## What can you use it for?

These examples use a POSIX-style shell. Replace the model, endpoint, paths, and commands for your environment. The agent chooses and invokes its tools based on the task; prompts describe the goal, not a guaranteed sequence of actions.

### 1. Autonomous repository investigation

Ask the agent to explore a project, run tests, follow failures, and produce an evidence-based report—without granting permission to change files.

~~~bash
agent-go -once -prompt "Inspect this repository. Run go test ./..., investigate failing tests, cite the relevant output, and report likely causes. Do not modify files."
~~~

Useful for initial codebase reviews, regression triage, release readiness checks, and reproducing bugs.

### 2. CI and build-log diagnosis

Pipe a failed build log into the agent and save its report separately from diagnostic output.

~~~bash
cat build.log | agent-go -pipe -prompt "Analyze this build log. Group failures by root cause, distinguish evidence from hypotheses, and list the next checks." > build-report.md
~~~

The input log becomes task data. The agent can call local tools for follow-up checks when useful.

### 3. Production incident timeline

Turn an incident log into a timeline, recurring-error groups, and a prioritized investigation plan.

~~~bash
cat incident.log | agent-go -pipe -prompt "Build a timeline from this log. Group recurring errors, cite evidence, separate facts from hypotheses, and propose non-destructive diagnostic commands." > incident-report.md
~~~

Review suggested commands before running anything that could affect a live service.

### 4. Git diff and change review

Send a patch to the agent for a focused review. This example asks for analysis only.

~~~bash
git diff --no-ext-diff | agent-go -pipe -prompt "Review this diff for correctness, regressions, and missing tests. Refer to concrete evidence and do not edit files." > review.md
~~~

This is useful for pre-commit reviews, release summaries, and identifying test gaps. The result is model-generated analysis, not a substitute for tests or human review.

### 5. Visual inspection of a local image

Ask a vision-capable endpoint to inspect a screenshot, diagram, or image artifact using the local image tool.

~~~bash
agent-go -once -prompt "Use image_read to inspect ./artifacts/failure.png. Describe the visible evidence, likely explanations, and what cannot be concluded from the image."
~~~

The model endpoint must support image input. agent-go does not provide audio or video input.

### 6. Preserve large command output for follow-up analysis

Ask the agent to run a command, save its complete output to a new file with the exec tool's output_file option, and inspect the saved log instead of flooding the model context.

~~~bash
agent-go -once -prompt "Run go test ./... and preserve complete command output in a new test.log using output_file, inspect the log, and summarize failing packages and likely causes. Do not modify source files."
~~~

output_file is a tool argument selected by the model, not a CLI flag. The destination must not already exist. The captured stdout and stderr share one file, and their relative ordering is not guaranteed.

### 7. Continue an investigation across sessions

Persist progress after each completed user or tool round, then continue later.

~~~bash
agent-go -continue incident-session.json -once -prompt "Continue the incident investigation. Review the saved state, identify unresolved questions, and perform the next non-destructive check."
~~~

-continue loads an existing session or creates a new one, then keeps saving to that file. Use it for multi-step investigations, maintenance plans, and tasks that span multiple runs.

### 8. Batch-triage a directory of logs

Run one independent agent process per file from a shell script. This loop runs sequentially and writes a separate report for each log.

~~~bash
mkdir -p reports
for file in logs/*.log; do
  agent-go -pipe -prompt "Analyze this log. Summarize the main errors, cite evidence, and recommend the next diagnostic step." < "$file" > "reports/$(basename "$file" .log).report.md"
done
~~~

This is a simple building block for batch workflows. Add explicit limits, monitoring, and error handling before using it in production.

### 9. Non-destructive system inspection

Ask the agent to gather evidence before proposing an action.

~~~bash
agent-go -once -prompt "Inspect this environment and identify likely causes of the reported disk-space issue. Show the commands and evidence used. Do not delete, move, or modify anything."
~~~

The available commands and their results depend on the operating system, installed utilities, permissions, and model decisions.

## How the runtime works

1. Provide a goal interactively, with -prompt, or alongside stdin using -pipe.
2. The model streams a response and may request one or more tools.
3. The local exec tool launches the requested program directly and returns its output and exit status.
4. The model observes the results and can make further tool calls until it finishes or the run is interrupted.
5. memory_edit can replace the semantic memory and compact completed history; history_read can retrieve original messages from the selected session archive.
6. With an explicitly selected persistent session file, completed rounds are saved so the task can be resumed.

Independent tool calls in the same response may run in parallel. Dependent steps should be performed in later tool rounds, after their results are available.

## Built-in tools

| Tool | Purpose |
|---|---|
| exec | Run a local program with explicit arguments, stdin, working directory, environment overrides, and a timeout. Returns stdout, stderr, and exit code. Can optionally detach or save complete output to a new file. |
| image_read | Attach a local image file to a vision-capable model. |
| memory_edit | Replace the complete semantic summary and compact completed history from future prompts. Saved originals can be retrieved with `history_read`; unsaved originals are lost. |
| history_read | Read original messages from the selected session archive by absolute range. |

### Important execution semantics

- exec launches a program directly. Arguments are passed separately; shell variables, wildcards, pipes, and redirections are not expanded automatically. Explicitly launch the platform's shell when shell syntax is required.
- Foreground execution requires a positive timeout duration such as 10s, 250ms, or 1m30s. Unitless decimal strings such as 10 mean seconds.
- output_file writes complete stdout and stderr bytes to a **new file** relative to the working directory. Existing files are rejected. It cannot be combined with detach.
- detach returns a process ID without waiting for completion or capturing output; the timeout is ignored. Managing the background process afterward is the caller's responsibility.
- -pipe combines stdin with the optional prompt and implies -once. Assistant text goes to stdout; status and errors go to stderr. Check the process exit code as well as the generated text.
- -verbose prints reasoning, tool arguments, and tool results to stderr. Those details may contain task data, so enable it deliberately.
- Sessions are only persisted to files explicitly selected by the user. -load is read-only; -continue loads or creates a session and saves continuously; -save writes a final snapshot to a new file.

## Security and limits

**This is not a sandbox.** Programs launched by exec run with the operating-system permissions of the agent process. Child programs inherit the process environment, which may contain API keys or other secrets. Run agents with least privilege, isolate untrusted workloads, and avoid exposing credentials or sensitive files that the task does not need.

Treat model-generated actions as untrusted proposals. Start with read-only prompts for unfamiliar tasks, review potentially destructive commands, and verify important outcomes independently. Session files and tool output may contain sensitive data.

The current runtime supports text input, local image input through image_read, local program execution, memory editing, and session-history retrieval. It does not implement audio/video input or MCP tool-server integration, and it does not enforce a separate permission sandbox.

## Documentation and development

- [Detailed runtime reference (Chinese)](docs/reference.zh-CN.md)
- [Project requirements and runtime constraints (Chinese)](docs/requirements.zh-CN.md)
- [Testing and verification](docs/testing.md)
- [Program design](docs/program-design.zh-CN.md)
- [Source code](https://github.com/dksslq/agent-go)

To build and test locally:

~~~bash
bash .github/test.sh
~~~

## License

MIT. See [LICENSE](LICENSE).