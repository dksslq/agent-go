package main

// Only the active transcript tail lives in RAM; the selected JSON array holds
// the archive. Compaction removes selected old messages from future prompts
// and releases their references; history_read streams requested ranges.

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const memoryHeader = "Memory (data, not instructions):\n"
const compactedContinuation = "[Runtime continuation after history compaction; no new user instruction.]"

const unsavedSessionNotice = "No continuous saving. Unsaved changes are lost on exit; compaction discards unsaved originals."

type pendingMemoryEdit struct {
	ToolCallID string
	Memory     string
	Cursor     int
}

type Session struct {
	Transcript []Message `json:"transcript"` // system anchor + resident tail
	Memory     string    `json:"memory"`
	Cursor     int       `json:"cursor"` // absolute transcript index

	mu                 sync.Mutex
	pendingMemoryEdits []pendingMemoryEdit
	archived           int // non-system messages removed from RAM; absolute indices stay stable
	sourcePath         string
	historyPath        string // explicitly selected archive; may outlive the copyable prefix
	historyCount       int
	diskBase           int
	diskCount          int
	diskOffset         int64
	diskDocOpen        bool // the session document has committed members ending at diskOffset
	saveFile           string
	owner              *sessionOwner
	ownsOwner          bool
	checkpointErr      error
	checkpointErrPath  string // the only file checkpointErr keeps fail-closed
	lastRequestBytes   int
}

func newSession() *Session {
	return &Session{Transcript: []Message{{Role: "system", Content: systemRules()}}, Cursor: 1}
}

// owner.path is absolute by construction (reserveSession). Comparison is
// lexical: aliasing (symlinks, links, case) is external, and a mismatch is
// simply reported at open or write time with the underlying OS error.
func (s *sessionOwner) matches(path string) bool {
	if s == nil || s.file == nil || path == "" {
		return false
	}
	absolute, err := filepath.Abs(path)
	return err == nil && absolute == s.path
}

func (s *Session) messageCountChecked() (int, error) {
	n, ok := addSessionInt(s.archived, len(s.Transcript))
	if !ok {
		return 0, errors.New("absolute session message count overflow")
	}
	return n, nil
}

// messageCount is a read-only convenience for display and tests. Mutating paths
// must use messageCountChecked and propagate the error rather than persist -1.
func (s *Session) messageCount() int {
	n, err := s.messageCountChecked()
	if err != nil {
		return -1
	}
	return n
}

func ensureSessionAppendFits(s *Session, count int) error {
	if count < 0 {
		return errors.New("negative session append size")
	}
	current, err := s.messageCountChecked()
	if err != nil {
		return err
	}
	if _, ok := addSessionInt(current, count); !ok {
		return errors.New("session message count overflow")
	}
	return nil
}

func appendSessionMessages(s *Session, messages ...Message) error {
	if err := ensureSessionAppendFits(s, len(messages)); err != nil {
		return err
	}
	s.Transcript = append(s.Transcript, messages...)
	return nil
}

func (s *Session) residentCursor() int {
	cursor := s.Cursor - s.archived
	if cursor < 1 {
		cursor = 1
	}
	if cursor > len(s.Transcript) {
		cursor = len(s.Transcript)
	}
	return cursor
}

func (s *Session) contextMessages() []Message {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.contextLocked()
}

func (s *Session) persistenceNotice() string {
	notice := unsavedSessionNotice
	if s.saveFile == "" {
		if s.sourcePath != "" {
			notice = fmt.Sprintf("Loaded snapshot: %q; read-only. ", s.sourcePath) + notice
		}
	} else {
		notice = fmt.Sprintf("Continuous saving: %q; completed history is saved before compaction.", s.saveFile)
		if s.owner != nil && s.owner.exclusive() {
			notice += " Exclusive archive access: history_read available; exec cannot reopen the file."
		}
	}
	if s.diskBase > 0 {
		notice += " Unsaved history gap: originals unavailable."
	}
	if s.historyPath != "" {
		notice += fmt.Sprintf(" Selected history archive: %q.", s.historyPath)
	}
	return notice
}

func (s *Session) contextLocked() []Message {
	if len(s.Transcript) == 0 {
		return nil
	}
	return s.contextLockedWithTail(s.Transcript[s.residentCursor():])
}

func (s *Session) runtimeContextMessage() Message {
	directory, err := os.Getwd()
	if err != nil {
		directory = "[unavailable]"
	}
	state := fmt.Sprintf("Runtime: cwd=%q.\n", directory) + s.persistenceNotice() + "\nMetrics: last_request_bytes=request JSON bytes, not tokens; history_next=exclusive archive end."
	if s.Memory != "" {
		state += "\n" + memoryHeader + s.Memory
	}
	return Message{Role: "system", Content: state}
}

func (s *Session) contextLockedWithTail(tail []Message) []Message {
	if len(s.Transcript) == 0 {
		return nil
	}
	out := make([]Message, 0)
	out = append(out, s.Transcript[0], s.runtimeContextMessage())
	if len(tail) > 0 && tail[0].Role == "assistant" {
		// Some compatible providers require a user message before assistant
		// history. Compaction can remove that user while retaining an in-flight
		// tool group; this runtime marker restores wire validity without
		// retaining consumed conversation or changing the saved transcript.
		out = append(out, Message{Role: "user", Content: compactedContinuation})
	}
	return append(out, tail...)
}

func (s *Session) contextBytesWithTailLocked(tail []Message) (int, error) {
	if len(s.Transcript) == 0 {
		return 0, nil
	}
	runtimeMessage := s.runtimeContextMessage()
	hasContinuation := len(tail) > 0 && tail[0].Role == "assistant"
	count := 2
	if hasContinuation {
		var ok bool
		count, ok = addSessionInt(count, 1)
		if !ok {
			return 0, errors.New("serialized context message count overflow")
		}
	}
	var ok bool
	count, ok = addSessionInt(count, len(tail))
	if !ok {
		return 0, errors.New("serialized context message count overflow")
	}
	return encodedMessageSizeAt(count, func(index int) Message {
		switch {
		case index == 0:
			return s.Transcript[0]
		case index == 1:
			return runtimeMessage
		case hasContinuation && index == 2:
			return Message{Role: "user", Content: compactedContinuation}
		case hasContinuation:
			return tail[index-3]
		default:
			return tail[index-2]
		}
	})
}

// Bytes are observable without guessing a provider's tokenizer/window size.
func (s *Session) contextBytes() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.Transcript) == 0 {
		return 0
	}
	size, err := s.contextBytesWithTailLocked(s.Transcript[s.residentCursor():])
	if err != nil {
		return -1
	}
	return size
}

// A tool-call group is indivisible. Completed groups may leave the context;
// the assistant currently awaiting results must remain until its tools finish.
func (s *Session) safeCursor(cursor int) int {
	cursorLimit, err := s.messageCountChecked()
	if err != nil {
		return -1
	}
	for i := 1; i < len(s.Transcript); i++ {
		calls := s.Transcript[i].ToolCalls
		if len(calls) == 0 {
			continue
		}
		absoluteStart, ok := addSessionInt(s.archived, i)
		if !ok {
			return -1
		}
		groupEnd := i + 1
		for groupEnd < len(s.Transcript) && s.Transcript[groupEnd].Role == "tool" {
			groupEnd++
		}
		if groupEnd-i-1 < len(calls) {
			cursorLimit = absoluteStart
			break
		}
		absoluteEnd, ok := addSessionInt(s.archived, groupEnd)
		if !ok {
			return -1
		}
		if cursor > absoluteStart && cursor < absoluteEnd {
			cursor = absoluteEnd
		}
		i = groupEnd - 1
	}
	if cursor == 0 || cursor > cursorLimit {
		cursor = cursorLimit
	}
	current := s.Cursor
	if current > cursorLimit {
		current = cursorLimit
	}
	if cursor < current {
		cursor = current
	}
	if cursor < 1 {
		cursor = 1
	}
	return cursor
}
func (s *Session) stageMemoryEdit(toolCallID, memory string, cursor int) string {
	if toolCallID == "" {
		return "Error: memory_edit requires a tool call ID"
	}
	if strings.TrimSpace(memory) == "" {
		return "Error: nonempty memory text is required; complete notes replace previous notes"
	}
	if cursor < 0 {
		return "Error: memory cursor must be nonnegative"
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if cursor > 0 && cursor < s.Cursor {
		return fmt.Sprintf("Error: memory unchanged; cursor %d cannot precede the current cursor %d", cursor, s.Cursor)
	}
	s.pendingMemoryEdits = append(s.pendingMemoryEdits, pendingMemoryEdit{
		ToolCallID: toolCallID, Memory: memory, Cursor: cursor,
	})
	return "Memory edit pending until this tool round's results are recorded."
}

func setMemoryEditResultAtLocked(s *Session, index int, result string) error {
	if index < 0 || index >= len(s.Transcript) {
		return errors.New("memory_edit result index is outside the transcript")
	}
	message := &s.Transcript[index]
	if message.Role != "tool" || message.Name != "memory_edit" {
		return errors.New("memory_edit result does not match its tool message")
	}
	raw, ok := message.Content.(string)
	if !ok {
		return errors.New("memory_edit result is not serialized JSON")
	}
	var wrapped ToolResult
	if err := json.Unmarshal([]byte(raw), &wrapped); err != nil {
		return fmt.Errorf("decode memory_edit result: %w", err)
	}
	wrapped.Result = result
	wrapped.EndUnix = time.Now().Unix()
	encoded, err := json.Marshal(wrapped)
	if err != nil {
		return fmt.Errorf("encode memory_edit result: %w", err)
	}
	message.Content = string(encoded)
	return nil
}

// applyPendingMemoryEdits runs only after the assistant's complete tool round is
// in Transcript. The checkpoint contains every result/attachment before it
// commits the new cursor, so a crash cannot hide an unrecorded side effect.
func (s *Session) applyPendingMemoryEdits() (bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	edits := s.pendingMemoryEdits
	s.pendingMemoryEdits = nil
	if len(edits) == 0 {
		return false, nil
	}
	oldMemory, oldCursor, oldArchived := s.Memory, s.Cursor, s.archived
	count, err := s.messageCountChecked()
	if err != nil {
		s.pendingMemoryEdits = edits
		return false, err
	}

	// Locate only the tool-result messages that this operation will change.
	// Do not clone the entire (possibly very large) active transcript merely
	// to support rollback after an I/O error.
	wanted := make(map[string]bool, len(edits))
	for _, edit := range edits {
		wanted[edit.ToolCallID] = true
	}
	indices := make(map[string]int, len(edits))
	for i := len(s.Transcript) - 1; i >= 0; i-- {
		message := s.Transcript[i]
		if message.Role == "tool" && message.Name == "memory_edit" && wanted[message.ToolCallID] {
			indices[message.ToolCallID] = i
			wanted[message.ToolCallID] = false
		}
	}
	type previousToolMessage struct {
		index   int
		message Message
	}
	previous := make([]previousToolMessage, 0, len(edits))
	for _, edit := range edits {
		index, ok := indices[edit.ToolCallID]
		if !ok || wanted[edit.ToolCallID] {
			s.pendingMemoryEdits = edits
			return false, fmt.Errorf("memory_edit result for tool call %q is missing", edit.ToolCallID)
		}
		previous = append(previous, previousToolMessage{index: index, message: s.Transcript[index]})
	}
	restore := func() {
		for _, old := range previous {
			s.Transcript[old.index] = old.message
		}
		s.Memory, s.Cursor, s.archived = oldMemory, oldCursor, oldArchived
	}

	// Keep the active tool round in the next model request. Earlier completed
	// rounds may be compacted, but this round's call/results must stay paired.
	editIDs := make(map[string]bool, len(edits))
	for _, edit := range edits {
		editIDs[edit.ToolCallID] = true
	}
	toolRoundStart := -1
	for i := len(s.Transcript) - 1; i >= 1; i-- {
		message := s.Transcript[i]
		if message.Role != "assistant" || len(message.ToolCalls) == 0 {
			continue
		}
		for _, call := range message.ToolCalls {
			if editIDs[call.ID] {
				absolute, ok := addSessionInt(s.archived, i)
				if !ok {
					s.pendingMemoryEdits = edits
					return false, errors.New("tool round start index overflow")
				}
				toolRoundStart = absolute
				break
			}
		}
		if toolRoundStart >= 0 {
			break
		}
	}
	if toolRoundStart < 0 {
		s.pendingMemoryEdits = edits
		return false, errors.New("memory_edit has no matching assistant tool-call group")
	}

	plannedMemory, plannedCursor := oldMemory, oldCursor
	valid := make([]bool, len(edits))
	status := make([]string, len(edits))
	lastSuccess := -1
	for i, edit := range edits {
		switch {
		case strings.TrimSpace(edit.Memory) == "":
			status[i] = "Error: nonempty memory text is required; complete notes replace previous notes"
			continue
		case edit.Cursor < 0:
			status[i] = "Error: memory cursor must be nonnegative"
			continue
		case edit.Cursor > 0 && edit.Cursor < plannedCursor:
			status[i] = fmt.Sprintf("Error: memory unchanged; cursor %d cannot precede the current cursor %d", edit.Cursor, plannedCursor)
			continue
		}
		s.Cursor = plannedCursor
		resolved := s.safeCursor(edit.Cursor)
		s.Cursor = oldCursor
		if resolved < 0 {
			status[i] = "Error: memory unchanged; cursor arithmetic overflow"
			continue
		}
		if resolved > toolRoundStart {
			resolved = toolRoundStart
		}
		if resolved < plannedCursor {
			status[i] = fmt.Sprintf("Error: memory unchanged; cursor %d cannot precede the current cursor %d", resolved, plannedCursor)
			continue
		}
		plannedMemory, plannedCursor = edit.Memory, resolved
		valid[i] = true
		lastSuccess = i
	}
	if lastSuccess >= 0 {
		for i := range edits {
			if !valid[i] {
				continue
			}
			if i == lastSuccess {
				status[i] = fmt.Sprintf("Cursor %d -> %d; next=%d; context_bytes=0.", oldCursor, plannedCursor, count)
			} else {
				status[i] = "Superseded by a later memory_edit in this tool round; only the final valid edit is applied."
			}
		}
	}
	setResults := func() error {
		for i, edit := range edits {
			if err := setMemoryEditResultAtLocked(s, indices[edit.ToolCallID], status[i]); err != nil {
				return err
			}
		}
		return nil
	}
	if err := setResults(); err != nil {
		restore()
		return false, err
	}
	if lastSuccess < 0 {
		return false, nil
	}

	// The reported context_bytes includes the completed memory_edit result when
	// the tool group is retained. Solve the tiny decimal-width dependency to a
	// fixed point without cloning the transcript or making the archive resident.
	var contextBytes int
	for {
		status[lastSuccess] = fmt.Sprintf("Cursor %d -> %d; next=%d; context_bytes=%d.", oldCursor, plannedCursor, count, contextBytes)
		if err := setResults(); err != nil {
			restore()
			return false, err
		}
		preview := &Session{
			Transcript: s.Transcript, Memory: plannedMemory, Cursor: plannedCursor,
			archived: oldArchived, sourcePath: s.sourcePath, historyPath: s.historyPath,
			historyCount: s.historyCount, diskBase: s.diskBase, diskCount: s.diskCount,
			diskOffset: s.diskOffset, diskDocOpen: s.diskDocOpen, saveFile: s.saveFile,
			owner: s.owner,
		}
		relative := plannedCursor - oldArchived
		resident := relative
		if relative > 1 && relative <= len(s.Transcript) {
			resident = relative
		} else {
			if resident < 1 {
				resident = 1
			}
			if resident > len(s.Transcript) {
				resident = len(s.Transcript)
			}
		}
		nextBytes, sizeErr := preview.contextBytesWithTailLocked(s.Transcript[resident:])
		if sizeErr != nil {
			status[lastSuccess] = fmt.Sprintf("Cursor %d -> %d; next=%d; context_bytes=unavailable (%v).", oldCursor, plannedCursor, count, sizeErr)
			if err := setResults(); err != nil {
				restore()
				return false, err
			}
			break
		}
		if nextBytes == contextBytes {
			break
		}
		contextBytes = nextBytes
	}

	checkpointed := false
	if s.saveFile != "" {
		// Keep prior in-memory cursor/summary metadata until the new state event
		// commits. Intermediate commits can only expose the previous cursor.
		if err := s.checkpointLocked(s.saveFile, plannedMemory, plannedCursor, count); err != nil {
			restore()
			s.checkpointErr, s.checkpointErrPath = err, s.saveFile
			return false, fmt.Errorf("%w: %w", errCheckpoint, err)
		}
		checkpointed = true
	} else if plannedCursor > s.diskCount {
		// The source did not contain the newly compacted originals.
		s.sourcePath, s.diskCount, s.diskBase, s.diskOffset, s.diskDocOpen = "", 0, 0, 0, false
	}
	s.Memory, s.Cursor = plannedMemory, plannedCursor
	s.compactLocked(plannedCursor)
	return checkpointed, nil
}

func (s *Session) editMemory(memory string, cursor int) string {
	if strings.TrimSpace(memory) == "" {
		return "Error: nonempty memory text is required; complete notes replace previous notes"
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.Transcript) == 0 {
		return "Error: memory unchanged; session transcript is empty"
	}
	if cursor < 0 || cursor > 0 && cursor < s.Cursor {
		return fmt.Sprintf("Error: memory unchanged; cursor %d cannot precede the current cursor %d", cursor, s.Cursor)
	}
	old := s.Cursor
	nextCount, countErr := s.messageCountChecked()
	if countErr != nil {
		return "Error: memory unchanged; " + countErr.Error()
	}
	cursor = s.safeCursor(cursor)
	if cursor < 0 {
		return "Error: memory unchanged; cursor arithmetic overflow"
	}
	if s.saveFile != "" {
		if err := s.checkpointLocked(s.saveFile, memory, cursor, cursor); err != nil {
			s.checkpointErr, s.checkpointErrPath = err, s.saveFile
			return fmt.Sprintf("Error: memory unchanged; checkpoint failed: %v", err)
		}
	} else if cursor > s.diskCount {
		// Unsaved originals are gone; a later save can only retain this suffix.
		s.sourcePath, s.diskCount, s.diskBase, s.diskOffset, s.diskDocOpen = "", 0, 0, 0, false
	}
	s.compactLocked(cursor)
	s.Memory, s.Cursor = memory, cursor
	contextBytes, sizeErr := s.contextBytesWithTailLocked(s.Transcript[s.residentCursor():])
	if sizeErr != nil {
		return fmt.Sprintf("Cursor %d -> %d; next=%d; context_bytes=unavailable (%v).", old, cursor, nextCount, sizeErr)
	}
	return fmt.Sprintf("Cursor %d -> %d; next=%d; context_bytes=%d.", old, cursor, nextCount, contextBytes)
}

func (s *Session) compactLocked(cursor int) {
	relative := cursor - s.archived
	if relative <= 1 || relative > len(s.Transcript) {
		return // safeCursor validates this range before persistent changes.
	}
	tail := []Message{s.Transcript[0]}
	tail = append(tail, s.Transcript[relative:]...)
	s.Transcript = tail
	s.archived = cursor - 1
}

func encodedMessageSize(messages []Message) (int, error) {
	return encodedMessageSizeAt(len(messages), func(index int) Message {
		return messages[index]
	})
}

func encodedMessageSizeAt(count int, messageAt func(int) Message) (int, error) {
	if count < 0 {
		return 0, errors.New("negative serialized message count")
	}
	size := 2 // JSON array brackets
	for i := 0; i < count; i++ {
		if i > 0 {
			var ok bool
			size, ok = addSessionInt(size, 1)
			if !ok {
				return 0, errors.New("serialized context size overflow")
			}
		}
		encoded, err := json.Marshal(messageAt(i))
		if err != nil {
			return 0, err
		}
		var ok bool
		size, ok = addSessionInt(size, len(encoded))
		if !ok {
			return 0, errors.New("serialized context size overflow")
		}
	}
	return size, nil
}

func (s *Session) close() {
	_ = s.release()
}

func (s *Session) release() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.ownsOwner {
		err := s.owner.close()
		s.ownsOwner = false
		s.owner = nil
		return err
	}
	return nil
}

// transcriptValidator rejects sessions that would send orphaned/ambiguous
// tool messages to a provider. Result order within a tool group may differ.
type transcriptValidator struct {
	count   int
	pending map[string]string
}

func (v *transcriptValidator) add(m Message) error {
	if v.count == 0 && m.Role != "system" {
		return errors.New("transcript must begin with a system message")
	}
	if len(v.pending) > 0 && m.Role != "tool" {
		return errors.New("assistant tool calls lack matching results")
	}
	if m.Role != "assistant" && len(m.ToolCalls) > 0 || m.Role != "tool" && m.ToolCallID != "" {
		return errors.New("tool metadata attached to an invalid message role")
	}
	if err := validateMessageContent(m); err != nil {
		return err
	}
	switch m.Role {
	case "system", "user":
	case "assistant":
		for _, call := range m.ToolCalls {
			args := strings.TrimSpace(call.Function.Arguments)
			if call.ID == "" || call.Function.Name == "" || call.Type != "function" || len(args) == 0 || args[0] != '{' || !json.Valid([]byte(args)) {
				return errors.New("invalid assistant tool call")
			}
			if v.pending == nil {
				v.pending = make(map[string]string)
			}
			if _, exists := v.pending[call.ID]; exists {
				return errors.New("duplicate tool call ID")
			}
			v.pending[call.ID] = call.Function.Name
		}
	case "tool":
		name, exists := v.pending[m.ToolCallID]
		if !exists || m.Name != "" && m.Name != name {
			return errors.New("orphaned or mismatched tool result")
		}
		delete(v.pending, m.ToolCallID)
	default:
		return fmt.Errorf("invalid message role %q", m.Role)
	}
	nextCount, ok := addSessionInt(v.count, 1)
	if !ok {
		return errors.New("transcript message count overflow")
	}
	v.count = nextCount
	return nil
}

func validateMessageContent(m Message) error {
	if _, ok := m.Content.(string); ok {
		return nil
	}
	if m.Role == "assistant" && m.Content == nil && len(m.ToolCalls) > 0 {
		return nil
	}
	if m.Role == "user" {
		switch blocks := m.Content.(type) {
		case []ContentBlock:
			if len(blocks) > 0 {
				for _, block := range blocks {
					if block.Type == "text" && block.Text != "" && block.ImageURL == nil {
						continue
					}
					if block.Type != "image_url" || block.ImageURL == nil || block.ImageURL.URL == "" || block.Text != "" {
						return errors.New("invalid user content block")
					}
				}
				return nil
			}
		case []interface{}:
			if len(blocks) > 0 {
				for _, raw := range blocks {
					block, ok := raw.(map[string]interface{})
					if !ok {
						return errors.New("invalid user content block")
					}
					if block["type"] == "text" {
						if _, ok := block["text"].(string); ok {
							continue
						}
					}
					if block["type"] == "image_url" {
						image, ok := block["image_url"].(map[string]interface{})
						if ok {
							if url, ok := image["url"].(string); ok && url != "" {
								continue
							}
						}
					}
					return errors.New("invalid user content block")
				}
				return nil
			}
		}
	}
	return fmt.Errorf("invalid content for %s message", m.Role)
}

func (v *transcriptValidator) finish() error {
	if v.count == 0 {
		return errors.New("empty transcript")
	}
	if len(v.pending) > 0 {
		return errors.New("assistant tool calls lack matching results")
	}
	return nil
}

// Writes only the user-selected file. Existing unrelated paths are never overwritten.
// A snapshot never transfers the active checkpoint handle or changes save mode.
// It borrows the source only while copying, then closes the new output.
func saveSession(path string, s *Session) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	owner, err := reserveSession(path, true)
	if err != nil {
		return err
	}
	if owner == nil {
		return errors.New("snapshot path is required")
	}
	if !owner.createdNew() {
		return errors.Join(errors.New("snapshot path already exists; choose a new file"), owner.close())
	}
	// The source can be exclusively held on Windows, so copy through its handle.
	copy := &Session{Transcript: s.Transcript, Memory: s.Memory,
		Cursor: s.Cursor, archived: s.archived, sourcePath: s.sourcePath,
		diskBase: s.diskBase, diskCount: s.diskCount, diskOffset: s.diskOffset, diskDocOpen: s.diskDocOpen,
	}
	// Source reads borrow s; the snapshot owns only its new output.
	copy.owner = owner
	copy.ownsOwner = true
	count, countErr := copy.messageCountChecked()
	cursor := copy.safeCursor(copy.Cursor)
	if countErr != nil || cursor < 0 {
		owner.close()
		if countErr != nil {
			return countErr
		}
		return errors.New("snapshot cursor arithmetic overflow")
	}
	err = copy.checkpointFromLocked(owner.path, copy.Memory, cursor, count, s)
	closeErr := owner.close()
	copy.owner, copy.ownsOwner = nil, false
	if err != nil || closeErr != nil {
		return errors.Join(err, closeErr)
	}
	if s.saveFile == "" {
		s.sourcePath, s.diskBase, s.diskCount, s.diskOffset, s.diskDocOpen = copy.sourcePath, copy.diskBase, copy.diskCount, copy.diskOffset, true
		s.historyPath, s.historyCount = copy.sourcePath, copy.diskCount
	}
	return nil
}

func checkpointSession(path string, s *Session) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	count, countErr := s.messageCountChecked()
	if countErr != nil {
		return countErr
	}
	cursor := s.safeCursor(s.Cursor)
	if cursor < 0 {
		return errors.New("snapshot cursor arithmetic overflow")
	}
	if err := s.checkpointLocked(path, s.Memory, cursor, count); err != nil {
		return err
	}
	s.saveFile = s.sourcePath
	s.historyPath, s.historyCount = s.sourcePath, s.diskCount
	s.Cursor = cursor
	return nil
}

func (s *Session) sourceFile() (*os.File, bool, error) {
	if s.owner.matches(s.sourcePath) {
		return s.owner.file, false, nil
	}
	f, err := os.Open(s.sourcePath)
	return f, true, err
}

func (s *Session) checkpointLocked(path, memory string, cursor, limit int) error {
	return s.checkpointFromLocked(path, memory, cursor, limit, s)
}

func (s *Session) checkpointFromLocked(path, memory string, cursor, limit int, sourceSession *Session) (err error) {
	if cursor < 0 || limit < 0 {
		return errors.New("negative checkpoint cursor or limit")
	}
	absolute, err := filepath.Abs(path)
	if err != nil {
		return err
	}
	// A failed checkpoint stays fail-closed for its own file only; a different
	// target never writes that file, it copies its last committed prefix.
	if s.checkpointErr != nil && s.checkpointErrPath == absolute {
		return s.checkpointErr
	}
	if cursor > 1 && strings.TrimSpace(memory) == "" {
		return errors.New("compacted session requires semantic memory")
	}
	end := limit - s.archived
	if end < 1 || end > len(s.Transcript) {
		return errors.New("invalid checkpoint boundary")
	}
	// Validate before creating even the explicitly requested output.
	v := transcriptValidator{}
	for _, m := range s.Transcript[:end] {
		if err := v.add(m); err != nil {
			return err
		}
	}
	if err := v.finish(); err != nil {
		return err
	}
	owner := s.owner
	acquired := !owner.matches(absolute)
	if acquired {
		owner, err = reserveSession(absolute, true)
		if err != nil {
			return err
		}
	}
	success := false
	defer func() {
		if acquired && !success {
			err = errors.Join(err, owner.close())
		}
	}()
	base, count, offset := s.diskBase, s.diskCount, s.diskOffset
	docOpen := s.diskDocOpen
	sameSource := s.sourcePath != "" && owner.matches(s.sourcePath)
	if !sameSource {
		if !owner.createdNew() {
			return errors.New("save path already exists; resume it or choose a new path")
		}
		if s.sourcePath != "" {
			source, closeSource, openErr := sourceSession.sourceFile()
			if openErr != nil {
				return openErr
			}
			if closeSource {
				defer func() { err = errors.Join(err, source.Close()) }()
			}
			if _, err := owner.file.Seek(0, io.SeekStart); err != nil {
				return err
			}
			// Preserve the committed array prefix and its state markers. This
			// keeps Save As streaming without making the whole archive one batch.
			copiedState, copyErr := readSessionLogPrefix(source, s.diskOffset, nil)
			if copyErr != nil {
				return copyErr
			}
			if copiedState.Count == 0 || copiedState.Offset != s.diskOffset {
				return errors.New("saved source has no complete checkpoint")
			}
			if _, err := owner.file.Seek(0, io.SeekStart); err != nil {
				return err
			}
			n, copyErr := io.CopyN(owner.file, io.NewSectionReader(source, 0, s.diskOffset), s.diskOffset)
			if copyErr != nil {
				return copyErr
			}
			if n != s.diskOffset {
				return io.ErrUnexpectedEOF
			}
			offset = s.diskOffset
			if _, err := owner.file.Write([]byte("\n]\n")); err != nil {
				return err
			}
			base, count, docOpen = copiedState.Base, copiedState.Count, true
		} else {
			base, count, offset, docOpen = s.archived, 0, 0, false
		}
	}
	start := 0
	if count > 0 {
		start = count - s.archived
		if start < 1 || start > len(s.Transcript) {
			return errors.New("saved history does not match resident suffix")
		}
	}
	if start > end {
		end = start
	} // earlier compaction may already be durable
	update := sessionUpdate{OpenDoc: docOpen, StreamCount: end - start}
	update.StreamAt = func(position int) (sessionMessage, error) {
		// The bounds established above guarantee start+position is within the
		// resident transcript. Construct just one index/message pair per visit.
		i := start + position
		var index int
		var ok bool
		if count == 0 {
			// The system message is first in the array; the retained suffix
			// uses absolute indexes after the compacted gap.
			if i == 0 {
				index, ok = 0, true
			} else {
				index, ok = addSessionInt(base, i)
			}
		} else {
			index, ok = addSessionInt(count, position)
		}
		if !ok {
			return sessionMessage{}, errors.New("absolute session message index overflow")
		}
		return sessionMessage{Index: index, Message: s.Transcript[i]}, nil
	}
	finalCount := count
	if update.StreamCount > 0 {
		var ok bool
		if count == 0 {
			finalCount, ok = addSessionInt(base, update.StreamCount)
		} else {
			finalCount, ok = addSessionInt(count, update.StreamCount)
		}
		if !ok {
			return errors.New("session message count overflow")
		}
	}
	// Every batch ends with a state event. Besides making memory/cursor changes
	// durable, this is the commit marker that lets recovery ignore a torn tail.
	update.State = &sessionState{Base: base, Count: finalCount, Cursor: cursor, Memory: memory}
	if offset > 0 {
		storedCount := count - base
		if storedCount < 1 {
			return errors.New("invalid saved history count")
		}
		update.Prior = &sessionLogState{
			Base: base, Count: count, StoredCount: storedCount,
			Cursor: s.Cursor, Memory: s.Memory, Offset: offset, DocOpen: docOpen,
		}
	}
	nextOffset, err := writeSessionUpdate(owner.file, offset, update)
	if err != nil {
		return err
	}
	count = finalCount
	if owner.createdNew() {
		if err := syncSessionDirectory(owner.path); err != nil {
			return err
		}
	}
	previous := s.owner
	previousOwned := s.ownsOwner
	s.owner, s.ownsOwner = owner, acquired || previousOwned
	s.sourcePath, s.diskBase, s.diskCount, s.diskOffset, s.diskDocOpen = absolute, base, count, nextOffset, true
	s.historyPath, s.historyCount = absolute, count
	owner.created = false
	success = true
	if acquired && previousOwned && previous != nil {
		return previous.close()
	}
	return nil
}

func loadSession(path string) (*Session, error) {
	stat, err := os.Stat(path)
	if err != nil {
		return nil, err
	}
	if !stat.Mode().IsRegular() {
		return nil, errors.New("session must be a regular file")
	}
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	return decodeSession(f, path)
}

func loadReservedSession(path string, owner *sessionOwner) (*Session, error) {
	if !owner.matches(path) {
		return loadSession(path)
	}
	return decodeSession(owner.file, owner.path)
}

// The session's own paths come from the caller's path, never from the handle
// name: on Windows an exclusively opened handle is named with a \\?\ prefix.
func decodeSession(f *os.File, path string) (*Session, error) {
	state, err := readSessionLog(f, nil)
	if err != nil {
		return nil, err
	}
	if state.Count == 0 {
		return nil, nil
	}
	absolute, err := filepath.Abs(path)
	if err != nil {
		return nil, err
	}
	s := &Session{Memory: state.Memory, Cursor: state.Cursor, sourcePath: absolute, diskBase: state.Base, diskCount: state.Count, diskOffset: state.Offset, diskDocOpen: state.DocOpen}
	_, err = readSessionLog(f, func(index int, m Message) error {
		if index == s.Cursor && m.Role == "tool" {
			if s.Cursor == sessionIntMaxValue() {
				return errors.New("session cursor overflow")
			}
			s.Cursor++
		}
		if index == 0 || index >= s.Cursor {
			s.Transcript = append(s.Transcript, m)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	s.archived = s.Cursor - 1
	if s.Cursor > 1 && strings.TrimSpace(s.Memory) == "" {
		return nil, errors.New("compacted session requires semantic memory")
	}
	s.historyPath, s.historyCount = absolute, s.diskCount
	return s, nil
}

// Only continue keeps an output open. Failure leaves any current session intact.
func continueSession(path string) (_ *Session, err error) {
	owner, err := reserveSession(path, true)
	if err != nil {
		return nil, err
	}
	if owner == nil {
		return nil, errors.New("continue path is required")
	}
	defer func() {
		if err != nil {
			err = errors.Join(err, owner.close())
		}
	}()
	s := newSession()
	if !owner.createdNew() {
		s, err = loadReservedSession(path, owner)
		if err != nil {
			return nil, err
		}
		if s == nil {
			return nil, errors.New("existing session file is empty")
		}
	}
	s.owner, s.ownsOwner, s.saveFile = owner, true, owner.path
	if owner.createdNew() {
		if err := checkpointSession(owner.path, s); err != nil {
			return nil, err
		}
	}
	return s, nil
}

func skipJSONValue(d *json.Decoder) error {
	token, err := d.Token()
	if err != nil {
		return err
	}
	delim, ok := token.(json.Delim)
	if !ok {
		return nil
	}
	if delim != '[' && delim != '{' {
		return errors.New("invalid JSON value")
	}
	for depth := 1; depth > 0; {
		token, err := d.Token()
		if err != nil {
			return err
		}
		if delim, ok := token.(json.Delim); ok {
			switch delim {
			case '[', '{':
				depth++
			case ']', '}':
				depth--
			}
		}
	}
	return nil
}
