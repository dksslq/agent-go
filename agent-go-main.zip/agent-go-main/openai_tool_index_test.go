package main

import (
	"fmt"
	"strings"
	"testing"
)

func TestSparseToolCallIndexIsRejectedWithoutDenseAllocation(t *testing.T) {
	withStreamDefaults(t)
	payload := fmt.Sprintf(
		"data: {\"choices\":[{\"index\":0,\"delta\":{\"tool_calls\":[{\"index\":%d,\"id\":\"call\",\"type\":\"function\",\"function\":{\"name\":\"exec\",\"arguments\":\"{}\"}}]},\"finish_reason\":\"tool_calls\"}]}\n\n",
		sessionIntMaxValue(),
	)
	err := consumeChatStream(strings.NewReader(payload), func(StreamEvent) error { return nil })
	if err == nil || !strings.Contains(err.Error(), "non-contiguous tool call index") {
		t.Fatalf("sparse provider index was accepted: %v", err)
	}
}
