package main

import (
	"path/filepath"
	"reflect"
	"strings"
	"testing"
)

func TestFullyCompactedSnapshotRoundTrip(t *testing.T) {
	dir := t.TempDir()
	s := newSession()
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "task"}, Message{Role: "assistant", Content: "done"})
	if result := s.editMemory("Task completed.", 0); strings.HasPrefix(result, "Error") {
		t.Fatal(result)
	}
	path := filepath.Join(dir, "snapshot.json")
	if err := saveSession(path, s); err != nil {
		t.Fatal(err)
	}
	loaded, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(loaded.close)
	if loaded.messageCount() != 3 || loaded.Cursor != 3 || loaded.archived != 2 || loaded.Memory != s.Memory || !reflect.DeepEqual(loaded.Transcript, s.Transcript) {
		t.Fatalf("compacted snapshot did not round trip: %+v", loaded)
	}
	copyPath := filepath.Join(dir, "copy.json")
	if err := saveSession(copyPath, loaded); err != nil {
		t.Fatal(err)
	}
	resumed, err := continueSession(copyPath)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(resumed.close)
	resumed.Transcript = append(resumed.Transcript, Message{Role: "user", Content: "next task"})
	if err := checkpointSession(copyPath, resumed); err != nil {
		t.Fatal(err)
	}
	resumed.close()
	messages, state := regressionReadSavedState(t, nil, copyPath)
	if len(messages) != 2 || messages[1].Content != "next task" || state.Base != 2 || state.Count != 4 || state.Cursor != 3 || state.Memory != s.Memory {
		t.Fatalf("resume lost the compaction gap: %+v; %+v", messages, state)
	}
}
