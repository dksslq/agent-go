package main

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"go/ast"
	"go/parser"
	"go/token"
	"image"
	"image/png"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestLargePayloadsKeepExactBytes(t *testing.T) {
	text := strings.Repeat("数据✓\n", 1<<20)
	got, err := pipePrompt("instruction", strings.NewReader(text))
	if err != nil || got != "instruction\n\n"+text {
		t.Fatalf("pipe changed large input: %v", err)
	}
	// The writer must keep draining even when the preview is bounded.
	for _, limit := range []int{0, 7} {
		out, err := newCommandOutput(limit, "", "")
		if err != nil {
			t.Fatal(err)
		}
		n, err := out.ReadFrom(strings.NewReader(text))
		if err != nil || n != int64(len(text)) {
			t.Fatalf("short drain: %d %v", n, err)
		}
		actual := out.finish()
		if limit == 0 && (actual != text || out.truncated) {
			t.Fatal("unlimited output was truncated")
		}
		if limit > 0 && (actual != string([]rune(text)[:limit]) || !out.truncated) {
			t.Fatal("Unicode preview boundary incorrect")
		}
	}
	s := newSession()
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: text})
	path := filepath.Join(t.TempDir(), "large.json")
	if err := saveSession(path, s); err != nil {
		t.Fatal(err)
	}
	loaded, err := loadSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(loaded.close)
	if loaded.Transcript[1].Content != text {
		t.Fatal("large session payload changed")
	}
}

func TestLargeImageToolKeepsCompleteAttachment(t *testing.T) {
	// A valid, poorly compressible PNG exceeds typical 1 MiB/4 MiB cutoffs.
	im := image.NewNRGBA(image.Rect(0, 0, 1536, 1024))
	seed := uint32(17)
	for i := range im.Pix {
		seed = 1664525*seed + 1013904223
		im.Pix[i] = byte(seed >> 24)
	}
	var encoded bytes.Buffer
	if err := png.Encode(&encoded, im); err != nil {
		t.Fatal(err)
	}
	if encoded.Len() < 4<<20 {
		t.Fatal("fixture did not cross 4 MiB")
	}
	path := filepath.Join(t.TempDir(), "large.png")
	if err := os.WriteFile(path, encoded.Bytes(), 0600); err != nil {
		t.Fatal(err)
	}
	args, _ := json.Marshal(map[string]string{"path": path})
	result, msg := runTool(context.Background(), newSession(), "image_read", string(args))
	if msg == nil {
		t.Fatalf("image failed: %s", result)
	}
	blocks, ok := msg.Content.([]ContentBlock)
	if !ok || len(blocks) != 2 {
		t.Fatal("missing image blocks")
	}
	_, b64, ok := strings.Cut(blocks[1].ImageURL.URL, ",")
	if !ok {
		t.Fatal("missing data URI")
	}
	data, err := base64.StdEncoding.DecodeString(b64)
	if err != nil || !bytes.Equal(data, encoded.Bytes()) {
		t.Fatalf("image bytes changed: %v", err)
	}
}

func TestSessionArrayInvariantFailures(t *testing.T) {
	encode := func(v interface{}) string {
		data, err := json.Marshal(v)
		if err != nil {
			t.Fatal(err)
		}
		return string(data)
	}
	message := func(m Message) string {
		return encode(sessionEvent{Message: &m})
	}
	state := func(base, count, cursor int, memory string) string {
		return encode(sessionEvent{State: &sessionState{Base: base, Count: count, Cursor: cursor, Memory: memory}})
	}
	system := message(Message{Role: "system", Content: "rules"})
	user := message(Message{Role: "user", Content: "task"})
	overflowState := strings.Replace(state(0, 1, 1, ""), "\"count\":1", "\"count\":9223372036854775808", 1)
	orphan := message(Message{Role: "tool", ToolCallID: "missing", Content: "x"})
	incomplete := message(Message{Role: "assistant", ToolCalls: []ToolCall{regressionCall("a", "exec")}})
	cases := map[string]string{
		"first non-system":      "[" + user + "," + state(0, 1, 1, "") + "]",
		"missing state":         "[" + system + "]",
		"unknown event":         "[" + encode(map[string]interface{}{"unexpected": 1}) + "," + state(0, 1, 1, "") + "]",
		"null message":          "[" + encode(map[string]interface{}{"message": nil}) + "," + state(0, 1, 1, "") + "]",
		"null state":            "[" + system + "," + encode(map[string]interface{}{"state": nil}) + "]",
		"missing memory":        "[" + system + "," + state(2, 3, 3, "") + "]",
		"cursor before base":    "[" + system + "," + state(2, 3, 2, "facts") + "]",
		"base changes":          "[" + system + "," + state(0, 1, 1, "") + "," + state(2, 3, 3, "facts") + "]",
		"count mismatch":        "[" + system + "," + state(0, 99, 1, "") + "]",
		"integer overflow":      "[" + system + "," + overflowState + "]",
		"cursor beyond tail":    "[" + system + "," + user + "," + state(0, 2, 3, "facts") + "]",
		"orphan tool":           "[" + system + "," + orphan + "," + state(0, 2, 1, "") + "]",
		"incomplete tool group": "[" + system + "," + incomplete + "," + state(0, 2, 1, "") + "]",
		"invalid role":          "[" + system + "," + message(Message{Role: "invalid", Content: "x"}) + "," + state(0, 2, 1, "") + "]",
		"multiple event fields": "[" + encode(map[string]interface{}{"message": Message{Role: "user", Content: "x"}, "state": sessionState{Base: 0, Count: 2, Cursor: 1}}) + "]",
		"extra root":            "[" + system + "," + state(0, 1, 1, "") + "][]",
	}
	for name, body := range cases {
		t.Run(name, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "session.json")
			if err := os.WriteFile(path, []byte(body), 0o600); err != nil {
				t.Fatal(err)
			}
			s, err := loadSession(path)
			if s != nil {
				s.close()
			}
			if err == nil {
				t.Fatal("invalid session event stream was accepted")
			}
			after, err := os.ReadFile(path)
			if err != nil || string(after) != body {
				t.Fatal("failed load modified its input")
			}
		})
	}
}

func TestEmptyRoundsStopOnRepeatedFailureWithoutTranscriptGrowth(t *testing.T) {
	for _, recoverAt := range []int{2, 0} {
		t.Run(string(rune('0'+recoverAt)), func(t *testing.T) {
			withStreamDefaults(t)
			var requests atomic.Int32
			withSSEServer(t, func(w http.ResponseWriter, r *http.Request) {
				io.Copy(io.Discard, r.Body)
				n := requests.Add(1)
				content := ""
				if recoverAt > 0 && int(n) == recoverAt {
					content = "recovered"
				}
				io.WriteString(w, deltaChunk(t, map[string]interface{}{contentField: content}, "stop"))
			})
			s := newSession()
			s.Transcript = append(s.Transcript, Message{Role: "user", Content: "finish"})
			err := runInferenceLoop(context.Background(), s)
			if recoverAt > 0 {
				if err != nil || requests.Load() != int32(recoverAt) {
					t.Fatalf("recovery: %v, calls=%d", err, requests.Load())
				}
			} else {
				if !errors.Is(err, errRoundRetry) || requests.Load() != 2 {
					t.Fatalf("identical failure was not detected: %v calls=%d", err, requests.Load())
				}
				notices := 0
				for _, m := range s.Transcript {
					if text, ok := m.Content.(string); ok && strings.HasPrefix(text, "[Runtime notice; not a user instruction]") {
						notices++
					}
				}
				if notices != 1 {
					t.Fatalf("retry failures accumulated runtime notices: %d; transcript=%+v", notices, s.Transcript)
				}
			}
			for _, m := range s.Transcript {
				if m.Role == "tool" || len(m.ToolCalls) > 0 {
					t.Fatal("empty stream dispatched tools")
				}
			}
		})
	}
}

func TestClosedCheckpointDoesNotDiscardMemory(t *testing.T) {
	path := filepath.Join(t.TempDir(), "active.json")
	s, err := continueSession(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(s.close)
	s.Transcript = append(s.Transcript, Message{Role: "user", Content: "must survive"})
	before := s.messageCount()
	oldMemory := s.Memory
	oldCursor := s.Cursor
	if err := s.owner.file.Close(); err != nil {
		t.Fatal(err)
	}
	if result := s.editMemory("replacement", 0); !strings.HasPrefix(result, "Error") {
		t.Fatal("closed checkpoint reported success")
	}
	if s.messageCount() != before || s.Cursor != oldCursor || s.Memory != oldMemory || s.Transcript[1].Content != "must survive" {
		t.Fatal("failed checkpoint discarded live state")
	}
}

func TestCanceledToolAndOutputDoNoWork(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	path := filepath.Join(t.TempDir(), "never-created")
	args, _ := json.Marshal(map[string]interface{}{"program": "never-start", "input": "", "timeout": "1", "output_file": path})
	result, _ := runTool(ctx, newSession(), "exec", string(args))
	if !strings.Contains(result, "canceled") {
		t.Fatal(result)
	}
	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Fatal("canceled tool created output")
	}
	f, err := os.CreateTemp(t.TempDir(), "output")
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	root, stop := context.WithCancel(context.Background())
	defer stop()
	out := newOutputWriter(root, f)
	if err := out.write(ctx, "must not write"); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	st, err := f.Stat()
	if err != nil || st.Size() != 0 {
		t.Fatal("canceled output wrote bytes")
	}
}

// Reject incompatible options before starting a process or creating its output file.
func TestExecDetachOutputConflictHasNoEffects(t *testing.T) {
	path := filepath.Join(t.TempDir(), "no-output")
	raw := execCmdOutput(context.Background(), "never-start", nil, "", time.Second, 0, "", nil, true, path)
	r := decodeExecResult(t, raw)
	if r.Error == "" || r.PID != 0 || r.ExitCode != nil {
		t.Fatalf("conflict launched command: %+v", r)
	}
	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Fatal("conflict created a file")
	}
}

func TestToolRoundIndexOverflowIsRejectedBeforeExecution(t *testing.T) {
	withStreamDefaults(t)
	s := newSession()
	t.Cleanup(s.close)
	s.archived = sessionIntMaxValue() - 1
	beforeMemory := s.Memory
	var requests atomic.Int32
	withSSEServer(t, func(w http.ResponseWriter, r *http.Request) {
		requests.Add(1)
		io.Copy(io.Discard, r.Body)
		io.WriteString(w, toolCallChunk(t, 0, "must-not-run", "memory_edit", `{"memory":"must not be applied"}`)+deltaChunk(t, nil, "tool_calls"))
	})
	err := runInferenceLoop(context.Background(), s)
	if err == nil || !strings.Contains(err.Error(), "message count overflow") {
		t.Fatalf("unrepresentable tool round was not rejected: %v", err)
	}
	if requests.Load() != 1 || len(s.Transcript) != 1 || s.Memory != beforeMemory {
		t.Fatalf("overflow changed session or ran the tool: requests=%d transcript=%+v memory=%q", requests.Load(), s.Transcript, s.Memory)
	}
}

func TestProductionDoesNotInspectRuntimePlatform(t *testing.T) {
	files, err := filepath.Glob("*.go")
	if err != nil {
		t.Fatal(err)
	}
	fset := token.NewFileSet()
	for _, filePath := range files {
		if strings.HasSuffix(filePath, "_test.go") {
			continue
		}
		file, err := parser.ParseFile(fset, filePath, nil, 0)
		if err != nil {
			t.Fatalf("parse %s: %v", filePath, err)
		}
		imports := make(map[string]string, len(file.Imports))
		for _, item := range file.Imports {
			importPath, err := strconv.Unquote(item.Path.Value)
			if err != nil {
				t.Fatalf("parse import in %s: %v", filePath, err)
			}
			name := importPath
			if slash := strings.LastIndex(name, "/"); slash >= 0 {
				name = name[slash+1:]
			}
			if item.Name != nil {
				name = item.Name.Name
			}
			imports[name] = importPath
		}
		var probes []string
		ast.Inspect(file, func(node ast.Node) bool {
			selector, ok := node.(*ast.SelectorExpr)
			if !ok {
				return true
			}
			pkg, ok := selector.X.(*ast.Ident)
			if !ok || imports[pkg.Name] != "runtime" {
				return true
			}
			if selector.Sel.Name == "GOOS" || selector.Sel.Name == "GOARCH" {
				probes = append(probes, selector.Sel.Name)
			}
			return true
		})
		if len(probes) > 0 {
			t.Errorf("%s inspects runtime platform constants %v; use platform-specific build constraints instead", filePath, probes)
		}
	}
}
